-------Speciesnames:--------
species 0	Otolemur_garnettii
species 1	Macaca_mulatta
species 2	Nomascus_leucogenys
species 3	Gorilla_gorilla
species 4	Pan_troglodytes
species 5	Homo_sapiens
species 6	Pongo_abelii
species 7	Tupaia_chinensis
species 8	Ochotona_princeps
species 9	Ctenodactylus_gundi
species 10	Petromus_typicus
species 11	Myocastor_coypus
species 12	Rattus_norvegicus
species 13	Mus_musculus
species 14	Nannospalax_galili
species 15	Jaculus_jaculus
species 16	Perognathus_longimembris
species 17	Marmota_marmota
species 18	Muscardinus_avellanarius
species 19	Solenodon_paradoxus
species 20	Erinaceus_europaeus
species 21	Crocidura_indochinensis
species 22	Condylura_cristata
species 23	Artibeus_jamaicensis
species 24	Bos_taurus
species 25	Sus_scrofa
species 26	Mustela_putorius
species 27	Equus_caballus
species 28	Tamandua_tetradactyla
species 29	Heterohyrax_brucei
species 30	Microgale_talazaci
species 31	Elephantulus_edwardii


y=1 OE:	ass	chr1	102888920	102888920	-	0
0	agga-a-gc--ttttta------aattggatga---ttct-c-tctctagggaattcccggtcctgccggtcccataggtccacctggtcctccaggctt
1	aggaaa-tc--ccttta------cattggctga---ttct-c-tctctagggaattcctggtcctgctggtccattaggtccacctggtcctccaggctt
2	agaaaa-tc--ccttta------aactggctga---ttct-c-tctctagggaattcctggtcctgctggtcccttaggtccacctggtcctccaggctt
3	agaaaa-tc--ccttta------aattggctga---ttct-c-tctctagggaattcctggtcctgctggtcccttaggtccacctggtcctccaggctt
4	agaaaa-tc--cattta------aattggctga---ttct-c-tctctagggaattcctggtcctgctggtcccttaggtccacctggtcctccaggctt
5	agaaaa-tc--ccttta------aattggctga---ttct-c-tctctagggaattcctggtcctgctggtcccttaggtccacctggtcctccaggttt
6	agaaaa-tc--ccttta------aattggctga---ttct-c-tctctagggaattcctggtcctgctggtcccttaggtccacctggtcctccaggctt
7	aggaaa-ag--tc--ta------aattggacaa---ttct-cctttttagggaattccaggtcctgctggtcccataggtccacctggtcctccaggctt
9	aggata-gc--tcatta------agtcggatca---ttct-c-ttggtagggaattccaggtcctgccggtcccataggtccacctggtcctccaggctt
10	aggaaa-ac--tcatta------aactgggtga---tttt-t-cctctagggattcccaggtcctgctggcccagttggcccacctggtcctccaggctt
12	-aatat-cc--ttacta------a-ttggatactcttccc-c-cctatagggcatcccaggtcctgctggtcccataggtcctcctggtcctccaggatt
13	-aagag-tc--ttatta------a-tcagatgctgtt-tt-c-ccgctagggcatcccaggtcctgctggtcccataggtccccctggtcctccaggatt
14	-gaaaa-tc--tcatta------aactttgtgc---ttct-t-ttcctagggaatcccaggtcctgctggtcccataggcccacctggtaacccaggatt
15	aaaacc-actctcttta------cacttggcgg---ttct-t-cctgtagggaatcccaggtcctgctggccccataggtccacctggtcctccaggact
17	aggaaa-ac--tcatta------aatcagatca---ttct-c-cctctagggaattccaggtcctgctggtcccataggcccacctggtcctccaggctt
19	agtgaa-ac--tcttta------atttggctga---ttct-c-ttcttagggaattccaggtcctgctggtcccataggcccacctggtcctccaggctt
20	tgg-aa-aa--tattta------ttttggatga---ttct-c-tccatagggaattccaggtcttgctggccctataggtccacctggtcctccaggctt
22	--gaaa-ta--tcttta------atttaaatga---ctct-c-tttctagggaattccaggtcctgctggtcccataggtccacctggtcccccaggctt
23	aggaag-ac--gctcta------atttgcatga---ttct-t-tctacagggaattccaggtcctgccggtcccatcgggccaccaggccctccaggttt
24	agaaaa-ac--tc--ta------atttgtatga---aacttc-tctgtagggaattccaggtcctgccggtcccattggtccacctggtcctccgggctt
25	agaaaaaac----ttta------atttggatga---ttct-c-tccatagggaattccaggtcctgctggccccataggtccacctggtcctccaggctt
26	aggaaa-ac--tc--ta------atttggatgc---ttct-c-tctgcagggaattccgggtcctgctggtcccataggtccacctggtcccccaggctt
27	ggaaaa-ac--ttttta------atttgcatga---ttct-c-tctatagggaattccaggtcctgctggtcccataggaccacctggtcctccaggctt
31	aggata-at--tttttattatttat-t--attt---attt-t-tatttagggtcttcctggctctcctggtcccttaggcccacctggacctccaggttt


y=1 OE:	ass	chr1	103008517	103008517	-	0
0	aatta---------aatta-ttatattcttactttttctccac-----aggggggacctggttcagctggggccaaaggtgagagtggtgatccaggtcc
1	aatta---------agtga--aatatcttcacttttt-tctat-----agggggggcctggttcagctggggccaaaggtgagagtggcgatccaggtcc
2	aatta---------agtga--aatatcttcactttttctctat-----agggggggcctggttcagctggggccaaaggtgagagtggtgatccaggtcc
3	aatta---------actga--aatatcttcactttttctctat-----agggggggcctggttcatctggggccaaaggtgagagtggtgatccaggtcc
4	aatta---------agtga--aatatcttcactttttctctat-----agggggggcctggttcatctggggccaaaggtgagagtggtgatccaggtcc
5	aatta---------agtga--aatatcttcactttttctctat-----agggggggcctggttcatctggggccaaaggtgagagtggtgatccaggtcc
6	aatta---------agtga--aatattttcactttttctctat-----agggggggcctggttcatctggggccaaaggtgagagtggtgatccaggtcc
7	agtga---------aatgt-ctatgcatttattttttctctac-----agggaggacctggttcagctggggccaaaggtgagagtggtgatccaggtcc
9	-ttta---------agtaa-ttgtttcctccatttttctcttt-----aggggggtcctggatcagctggggccaaaggggagagtggtgatccaggtcc
12	-----ttaacattgattgg-ttgtctgctttgcttttctcctc-----aggggggtcctggttcagctggagccaaaggtgagagtggggatccaggtcc
13	-----ttaacattaattgg-tcgtctgttttgcttctatcctc-----aggggggtcctggttcagctggagccaaaggtgagagtggggatccaggtcc
14	agtta---------atcag-ttatctccttt-cttttctctat-----agggtggacctggatcatctggggccaaaggagagagtggtgatccaggtcc
15	aatta---------gtaag-ttatgtgctcaacttttctctac-----agggcggtcctggttcagctggagccaagggtgagagtggtgatccaggtcc
17	actta---------aatga-ttatgccttcaatttttcttgac-----agggtgggcctggttcagctggggccaaaggtgagagtggtgacccaggtcc
19	gatga---------actaa-tcatatcctcactttttctctat-----agggtggacctggttcatcaggggccaaaggtgagagtggtgacccaggtcc
20	aatta---------aataa-ttatttcctcacttt-tatttat-----aggggggtcctggctcaactggtgccaaaggtgagagtggtgatccaggtcc
22	aatta---------aatga-ttatatcctt----attttctac-----agggggggccaggatcatctggggcaaaaggtgagagtggagatccaggtcc
24	aatta---------aatga-atatgtcttcactttttctctac-----agggcgggcctggttcttctggggccaaaggtgagatgggtgatccaggtcc
25	-----------------ga-ttataccttcactttttctctgc-----aggggggtcctggttcatctggggccaaaggcgagagtggtgaaccaggtcc
26	aatta---------aatga-ttttattctttctttttctctat-----agggggggcctggttcatctggtgccaaaggtgagagtggtgatccaggtcc
27	aatta---------aatga-ttataccctcactttttctctgc-----agggcgggcctggttcatctggagccaaaggtgagagtggtgatccaggtcc
31	aataa---------aattaattatatattcacttt--ttttttcctacaggggggaccaggttcatcaggggccaaaggtgagagtggtgatccaggccc


y=1 OE:	dss	chr1	102888722	102888722	-	0
0	gcat-t--ttgtagggtcctcaaggcccaaagggtaacaaaggctcttctgtaagtac-ttttttcttcggcatttttatttttcagtga-tcctggtta
1	gcat-t--ttctagggtcctcaaggcccaaagggtaacaaaggttctactgtaagtac-ttttccctttgacaatttaatttttcattgaaacctattta
2	gcat-t--ttgtagggtcctcaaggcccaaagggtaacaaaggctctactgtaagtac-ttttccctttggcaatttaattttgcatttaaacctattta
3	gcat-t--ttgtagggtcctcaaggcccaaagggtaacaaaggctctactgtaagtac-ttttccctttgacaatttaattttgcattgaaacctattta
4	gcat-t--ttgtagggtcctcaaggcccaaagggtaacaaaggctctactgtaagtag-ttttccctttgacaatttaattttgcattgaaacctattta
5	gcat-t--ttgtagggtcctcaaggcccaaagggtaacaaaggctctactgtaagtac-ttttccctttgacaatttaattttgcattgaaacctattta
6	gcat-t--ttgtagggtcctcaaggcccaaagggtaacaaaggctctactgtaagtac-ttttccctttgacaatttaattttgcattgaaacctattta
7	gcat-t--ttctagggtcctcaaggtccaaagggcaacaaaggctctagtgtaagtac-ttttcctttttgcattttaatttctcaatgaagcgtcttct
9	gcat-t--ttctagggtcctcaaggcccaaagggtaacaaaggctcttctgtaagtac-ttttctctttgacattttaactt---aacgaagcctattaa
10	gaat-t--ctctagggtcctcaagggctaaagggtaataaaggctcttctgtaagtat-ttttccctttgacattgtaacttttcagtgaggcataatgc
12	gtgt-t--ttctagggtcctgctggtccgaagggtaacaaaggatcttctgtaagtgc-ttgtctcctttgaatagtagtgcttcagtgaagtctgtggc
13	gtgt-t--ttccagggtcccgctggcccgaagggtaacaaaggatcatctgtaagtgc-ttttctcctttgaatagcagtgctttgatgaagcctgttgc
14	gtct-t--ttctagggtcctcaaggccctaagggtaacaaaggctcttctgtaagtac-ttttctcattga-----taagttttcaataaag-ctattac
15	ccccccccccacagggtcctcaaggcccaaagggtaacaaagggtcttcggtaagtgc-tttg--tgttggcatactcaactttcaaggaagtctattaa
17	gcat-t--ttctagggtcctcaaggtcccaagggtaacaaaggctcctctgtaagtgc-ttctccctttgacattttaatttttgagtgaagtccattaa
19	gcat-t--ttctagggaccccaaggcccaaaaggtaccaaaggttctactgtaagtac-ttttcctt-tggcatttaattttttcagtgaagcctatcta
20	gtat-t--ttccagggccctcaaggtccaaagggtaacaaaggctcttctgtaagtac-ttgttcttttggcatttaattggcccat--atgtctatcta
22	gtat-t--ttatagggtcctcaaggtccaaagggtaacaaaggctctactgtaagtat-ttgtccttcggtgatggcattttttcagtgaaggccacctg
23	gcat-t--ttctagggtcctcaaggccccaagggcaacaaaggctccacagtaagtaccct-cccctttggcatttccatttcggggtgcagcctgctcc
24	gctt-t--ttttagggtcctcaaggtccaaagggcactaaaggctctacggtaagtac-ctttccctttagcatttaaagttttcagtgatgcctactca
25	gcat-t--ttctagggtcctcaaggtccaaagggtaccaaaggctctactgtaagtat-ctttccctttgtcgtttaa-tttttcagtgaaacctactca
26	gctt-t-tttctagggccctcaaggtccaaagggtaccaaaggctctgctgtaagtac-ttttgcatttgg-gttttcatttttcagggaagtccactca
27	gcat-t--ttctagggtcctcaaggtccaaagggtaccaaagggtctacagtaagtac-ttttctcattggcattttaatttttcagtgaagcctactca
31	ctgt-t--ttctagggtcctcaaggtccaaagggtaacaaaggctctactgtgagtac-ttgcctctttgacattttggggttttggt---ga-tattca


y=1 OE:	dss	chr1	102913636	102913636	-	0
0	aagatggtgtcagtggtgacaagggtgaagatggagatactggtcaaccagtaagt------a----a-----ac---c--t-a------tt-t------
1	aagatggtgttggtggtgacaagggtgaagatggagatcctggccaaccggtgagtaa-at-g----c-----actatt--t-t-------t-t------
2	aagatggtgttggtggtgacaagggtgaagatggagatcctggtcaaccggtgagtaa-at-g----c-----actaac--t-t-------t-t------
3	aagatggtgttggtggtgataagggtgaagatggagatcctggtcaaccggtgagtaa-at-g----c-----actaat--t-t------at-t------
4	aagatggtgttggtggtgacaagggtgaagatggagatcctggtcaaccggtgagtaa-at-g----c-----actaat--t-t------at-t------
5	aagatggtgttggtggtgacaagggtgaagatggagatcctggtcaaccggtgagtaa-at-g----c-----actaat--t-t------at-t------
6	aagatggtgttggtggtgacaagggtgaagatggagatcctggtcaaccggtgagtaa-at-g----c-----actaat--t-t------at-t------
7	aagatggagttggtggtgataagggtgaagatggagatcctggtcagccggtaagtaa-gg-a----c-----aa---t--a--------tc-t------
9	aagatggtgtcggtggtgacaagggtgaagatggagaccccgggcagccggtgagtaa-gc-a----c-----ag---t--g-a------tc-a------
10	aagatggagtcggtggtgacaagggtgaagatggagatcccggacagccggtgagcaa-gt-g----g-----ag---t--a-a------t-tt------
12	aagatggtgttggaggtgacaagggtgaagatggagatccaggacaaccagtaagcaa-ga-aaccgt---------------a------ct-t------
13	aagatggtgttggaggtgacaagggtgaagatggagatccaggacaaccagtaagcaa-g---acctt---------------a------cc-t------
14	aagatggtgttggtggtgataagggtgaagatggcgatccagggcaaccggtaagcaa-ga-ctactc---------------a------cc-t------
15	aagacggtgttggcggtgacaagggtgaagatggcgatcctggtcagccggtgagcaa-gc-agtttc---ctgg---t--g-t------ctat------
17	aagatggtgttggtggtgacaagggtgaagatggagatcctgggcaaccggtaagaaa-gc-c----c-----at---t--aaa------tt-t------
19	aagatggtgttggtggtgacaagggtgaagatggagatcctggtcaaccggtaaatga-ga-a----a--caatt---ttta--ataaatat-taatttt
20	aagatggtattggtggtgacaagggtgaagatggagatcctggtcaacaggttagtaa-gc------t--ctgtt---ttca------------------
22	aagatggtgttggtggtgataagggtgaagatggagatcctggccagccggtaagcaa-gcat----a--ccatt---ttta--ttcagtat-t------
23	aagatggcgttagcggtgacaagggtgaagatggagaccctggtcagccggt-aggca-gc-a-caca--ctact---tcga------------------
24	aagatggtgttggtggtgacaagggtgaagatggagatcctggacaaccggtaagtaa-gc-a-----cactat----ttta--tttagttt-c------
25	aagatggtgttggtggtgacaagggtgaggatggagatcctggtcaaccagtaagtaa-gctc----a--ctttt---taaa--tttaatct-g------
26	aagatggcgttggtggtgacaagggtgaagatggagatcctggtcagccggtaagtaa-gcat----a--ctatt---ttta--ttagatct-t------
27	aagatggtgttggtggtgacaagggtgaagatggagatcccggtcaaccggtaagcaa-gctt----a--ctgtt---ttca--tttcatct-t------
31	aagatggtgttggaggtgacaaaggtgaagacggagatcctggtcaaccagtaagtaaact-c----a--cttct---c--t-t------tt-t------


y=1 OE:	dss	chr1	103541476	103541476	+	0
0	aagataaaggatatgctgatcacacct---t---cgtctgcttcccacaggtaatt--gtattctgagttaggaa-gtgaagg---ttgtctgt--gtg-
2	aaaataaaggatatgttgaatacacct---t---tgtgtccttcacacaggtaatt--ttattt-aaactatgaa-atgaggg---ttgtttgtatgtg-
3	aaaataaaggatatgttgaatacacct---t---tgtgtccttcacacaggtaatt--ttattt-gaactaagaa-atgaggg---ttgtctgtatgta-
4	aaaataaaggatatgttgaatacacct---t---tgtgtccttcacacaggtaatt--ttattt-gaactaaaaa-atgaggg---ttgtctgtatgta-
5	aaaataaaggatatgttgaatacacct---t---tgtgtccttcacacaggtaatt--ttattt-gaactaagaa-atgaggg---ttgtctgtatgta-
6	aaaataaaggatatgttgaatacacct---t---tgtgtccttcacacaggtaatt--ttattt-gaactatgaa-atgaggg---ttgtctgtatgta-
7	aaaataaaggatatgttgaatacacca---a---catctgcgtcacacaggtaattatttttttttaattatgaa-attaggg---ttttctgtatgta-
8	aaaataaaggatatgctgagtgcatct---t---catctgcttcgcacaggtaatt--ttgttcagaattatt---atgaggg---ttatctgtatatt-
12	aaaataaaggacatgttgactgtacct---t---caccagcttcccaaaggtgatt--ttgtttatagttatgag-atga-ag---ttgtctgtttgtg-
13	aaaataaaggatatgttgaatatacct---t---catcagcttcacataggtaatt--ttatgtatacctaggaa-atgagag---ttgtctataagtg-
15	aaaataaaagatatgctgaatatccct---t---catctgcatcacacaggtaatt--ttctgcaggattctgca-ttgagggatggtgtcgatatgcag
17	aaaataaaggatatgttgaatacaccc---t---catcttcttcacacaggtagtt--ttatatagaattacgaaagtgaatg---ctgtccatatgta-
19	aaaattaaggatatgttgaatacaccc---t------ctgcttcacaaaggtaatt--ttattcaggcttatgaa-attaggg---ctctttttctata-
20	aaaataaaagatatgctgaatatacct---tcat---ctgcttcacacaggtaatt--ttgtttggaattatata-ataagg--------taatacata-
22	aaaataaaggatatgttgaatatacct---tcat---ccgcctcacacaggtaact--tgttttttaactacgaa-at---gt---t--tctgtatgcc-
24	aaaataaaggatatgttgaatataccatcat------ctgcttcacacaggtagtt--ttgttttagattatacg-ataagag---tt--ctttatata-
26	aaaataaaggatatgttgaaaacacctccat------ctgctccgcaaaggtaatt--ttgtt-----ttatgaa-ataag-----tt--tcctgtgta-
27	aaaataaaggatatgttgattacacct---tcac---ctgcttcacacaggtaact--ttgttttgaattatgaa-ataaagg---tt--ctgtatgtt-


y=0 OE:	ass	chr1	102939358	102939358	-	0
0	atgtgtgattatagtttctat--gaatcaatgtactttcatta---tcagcttataatagttatatttga-------gacaaaattgatatttta-gtta
1	atgtgtaattatagattttat--aaatcagtgtacttccatta---tcagtttatacaggtaatatttga-------gacacatttgcatttttaagtta
2	atgtgtaattatagattttat--aaatcagtgtacttccatta---tcagtttatacaggtaatatttga-------gacaaaattgatttttta-atta
3	atgtgtaattatagattttat--aaatcagtgtatttccgtta---tcagtttatacaggtaatatttga-------gacaaaattgatttttga-atta
4	atgtgtaattatagattttat--aaatcagtgtatttccatta---tcagtttatacaggtaatatttga-------gacaaaattgatttttga-atta
5	atgtgtaattatagattttat--atgtcagtgtatttccgtta---ccagtttatacaggtaatatttga-------gacaaaattgatttttga-atta
6	atgtgtaattatagattttat--acatcagtgtacttccatta---tcagtttatacaggtaatatttga-------gacaaaattgatttttta-atta
15	atatgcaattata-tgtctat--gaatgaatgcactctcatta---tcagcttgtcatggct-------atattcaagac--aatcagtttttta--ttg
24	atgtgtaattata-tttttatataaatcagtgtatttccatta---tcagtttatactggtgttatttca-------gatgaaattgattttgtgaattg
31	atatgtaattaaa-tttgttaataaatcaatgtatttttattatgttcagtttatagtggtgatattaga-------gccaaaactggctttctttat--


y=0 OE:	ass	chr1	103029948	103029948	-	0
1	ttcaaggttgatgagatctgt------ttt-gctcc-tttataaagaaagataaggcatattattctttttagcaacagatatggctctgatttttggaa
2	ttcaaggttgatgagatctgt------ttt-gctcc-tttataaagaaagataaggcatattattctttttagcaacagatatggctctgatttttggaa
3	ttcaaggttgatgagatctgt------ttt-gctc--tttataaagaaagataaggcatattattctttttagccacagatatggctctgatttttggaa
4	ttcaaggttgatgagatctgt------ttt-gctcc-tttataaagaaagataaggcattttattctttttagcaacagatatggctctgagttttggaa
5	ttcaaggttgatgagatctgt------ttt-gctcc-tttataaagaaagataaggcatattattctttttagcaacagatatggctctgatttttggaa
6	ttcaaggttgatgagatctgt------ttt-gctcc-tttataaagaaagataaggcatattattcttgttagcaacagatatggctctgatttttggaa
24	tttaagacagatgagatttattaatatt-ttgctcc-tgttttaagaaagataagac---ttgtcctttttagcaacagatatggctctgatttttggaa
26	tttgagattgctgagatttat------t-ttgctcc-tgttttaagaaagataagtt---ttgttctttttagcaacagatatggctctgatttttggaa
27	ttcaagattgatgagatttat------t-ttggtcc-tattttaagaaagatgagtc---ttcttctttttagcaacagatatgcctctgatttttggaa
28	ttcatgatttatgatacttat------t-t-cattcttactttaagagagataaggc---ttattctttttagcaacagatatggccctgatttttggga


y=0 OE:	ass	chr1	103025848	103025848	-	0
0	aaaagcccaaaaagtttacaccccccaaatctgaaacattttcatccaagaagaagaaaagttaccaagcatcagccaaagccaagctaggggtcaaggt
1	aaaagtccaaaaagtttacaccccccaaatctgaaaaattttcatccaagaagaagaaaagttatcaagcatcagcaaaagccaaactaggggtaaaggt
2	aaaaatccaaaaagtttacacccccaaaatctgaaaaattttcatccaagaagaagaaaagttatcaagcatcagcaaaagccaaactaggggtaaaggt
3	aaaaatccaaaaagtttacaccccccaaatctgaaaaattttcatccaagaagaagaaaagttatcaagcatcagcaaaagccaaactaggggtaaaggt
4	aaaaatccaaaaagtttacaccccccaaatctgaaaaattttcatccaagaagaagaaaagttatcaagcatcagcaaaagccaaactaggggtaaaggt
5	aaaaatccaaaaagtttacaccccccaaatctgaaaaattttcatccaagaagaagaaaagttatcaagcatcagcaaaagccaaactaggggtaaaggt
6	aaaaatccaaaaagtttacaccccccaaatctgaaaaattttcatccaagaagaagaaaagttatcaagcatcagcaaaagccaaactaggggtaaaggt
7	aaaagtccaaaaagtttacaccccccaaatctgaaaaatttgcatccaagaagaagaaaagttaccaagcagcagcaaaagccaaactaggggtcaaggt
8	aaaagcccaaaaagtttacaccccccaaatctgaaaaatttgcatcaaagaagaagaaaacttaccgagc---tgcaaaagccaaactaggggtaaaggt
9	aaaaatccaaaaagttcacacaccccaaatctgaaaaatttgcctccaagaagaagaaacgtaaccaagcagaagcaaatggcagactaggggtaaagtt
11	aaaagcccaaaaagtttatactccccatatctgaaaaatttgcattccagaagaagaaaagtaatcaagctgcagcaaaagccaaattaggggtaaaagt
12	aaaaatctaaaatgtccacaacccccaaatctgaaaagtttgcatccaagaagaagaaacgtaaccaagccacagccaaagccaaactaggggtccaggt
13	aaaaaactaaaaagttcacatcccccaaatctgaaaaatttgcatccaagaagaagaaacgtaatccagccacagccaaagccaaactaggggtccaggt
14	aaaattctaaaaagttcacactcccaaaatctgaaaaaattgcatcaaagaagaagaaaaattaccaggcagcagcaaaagccaaactaggggtccaggt
15	ccaaacctaaaaagtttacaccccccaaatctgaaaagcttgcatccaagaggaagaacagttatcaagcaacagccagagcccagctaggggtccaggt
17	aaaaactcaaaaagtttacaccccccaaaa---------------ccaagaagaagaaaagttatcaagcagcagcaaaagccaaactaggggtaaaggt
20	aaaagtccaaaaagtttacaccccctaaatctgaaaaatttgcatcaaagaagaaggaaagttatcaagcaacagcaaaagccaaactaggggtacaggt
22	aaaagtccaaaaagtttacgccccctaaatctgaaaaaattgccaccaagaagaagaaaagttatcaagcaacagcaaaagccaaactaggggtaaaggt
23	aaaaggccaaaaagcttacaccccctaaatctgaaacatttgcatccaagaagaagaaaagttatcaagcagcggcaaaaaccaaactaggggcccaggt
24	aaaagtccaaaaagtttacaccccctaaatctgaaaaatttgcatccaagaagaagaaaacttatcaagcagcagcaatggccaagctaggggtaaaggt
26	aaaagtccaaaaagtttacaccccctaaatctgaaaaatttgcgtccaagaagaagaaaagttatcaagcagcagcaaaagccaaactaggggtaaaggt
27	aaaagtccaaaaagtttacaccccctaaatctgaaaaatttgcatccaagaagaagaaaagttatcaagcagcagcaaaggccaaactaggggtgaaggt
28	aaaagtccaaaaagtttacaccccccaaatctgaaaaatttgcctccaagaagaagaaaagttatcaagcagcagcaaaagccaaactaggggtccaggt
31	aaaaatctaaaaagtttaaaccccccaaatctgaaaaatttgcatccaagaagaagaaaagttatcaagcaacagcaaaagccaaactaggggtaaaggt


y=0 OE:	dss	chr1	103458233	103458233	+	0
4	tcttaagctttatgactaatatgtttttt---cccttaaattataaatgggt--gtgtgtgtgtgcgcgcgtgtgtgtttg--tgt------gtgtg---
5	tcttaagctttatgactaatatgtttttt---cccttaaattataaatgggt--gtgtgtgtgtgcgcgcgtgtgtgtttg--tgtgtgtgtgtgtg---
8	aactaagtttcatgactaatgtgtttttt---cccttaactcattgggatgtgt--------------------------g--------------tg---
24	ttctgagctttatgactgatgcgtttttttccctcttaaatcatagggaagtgt--------------------------g--------------tgtgt
27	tcctgagctttatgactaatgtgatgttt---tcctcaaatcatagggatgtgt--------------------------gtg------------tg---


y=0 OE:	dss	chr1	102937442	102937442	+	0
1	aagaaatctaaatggaatctaaagtaatttactgctatcatttgcatatggtttgtccccactgaacctcatgttgaaatctaattcccaatgttgaagg
2	aagaaatctaaatggaatctgaagtaatttactgctatcgtttggatatggtttgtccccactaaagctcatgttgaaatttaattcccagtgttggggg
3	acgaaatctaaatggaatctaaagtaatttactgctatcgtttggatatggtttgtccccactaaaactcatgttgaaatttaattcccagtgttggggg
4	acgaaatctaaatggaatctaaagtaatttactgctgtcgtctggatatggtttgtccccactaaaactcatgttaaaatttaattcccagtgttggggg
5	aagaaatctaaatggaatctaaagtaatttactgctatcgtttggatatggtttgtccccactaaaactcatgttgaaatttaattcccagtgttggggg
6	aagaaatctaaatggaatctaaagtaatttactgctatcgtttggatatggtttgtccccactaaagctcatgttgaaatttaattcccagtgttggagg
