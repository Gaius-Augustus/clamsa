-------Speciesnames:--------
species 0	Otolemur_garnettii
species 1	Macaca_mulatta
species 2	Nomascus_leucogenys
species 3	Gorilla_gorilla
species 4	Pan_troglodytes
species 5	Homo_sapiens
species 6	Pongo_abelii
species 7	Tupaia_chinensis
species 8	Ochotona_princeps
species 9	Ctenodactylus_gundi
species 10	Petromus_typicus
species 11	Myocastor_coypus
species 12	Rattus_norvegicus
species 13	Mus_musculus
species 14	Nannospalax_galili
species 15	Jaculus_jaculus
species 16	Perognathus_longimembris
species 17	Marmota_marmota
species 18	Muscardinus_avellanarius
species 19	Solenodon_paradoxus
species 20	Erinaceus_europaeus
species 21	Crocidura_indochinensis
species 22	Condylura_cristata
species 23	Artibeus_jamaicensis
species 24	Bos_taurus
species 25	Sus_scrofa
species 26	Mustela_putorius
species 27	Equus_caballus
species 28	Tamandua_tetradactyla
species 29	Heterohyrax_brucei
species 30	Microgale_talazaci
species 31	Elephantulus_edwardii


y=1 OE:	ass	chr1	181726064	181726064	+	0
0	-------ttgtggaggtcccctggtaaagccatatctgctttgtgcctaggatgaacaagaggaagaagaggccttcaaccagaaacacgcactgcagaa
2	-------tcctggggatccc-aggcaaagccatctctgctttgtgtctaggatgaacaggaggaagaagaggccttcaaccagaaacatgcactgcagaa
3	-------tcctggggatccc-aggcaaaaccatctctgctttgtgtctaggatgaacaggaggaagaagaggccttcaaccagaaacatgcactgcagaa
4	-------tcctggggatccc-aggcaaagccatctctgctttgtgtctaggatgaacaggaggaagaagaggccttcaaccagaaacatgcactgcagaa
5	-------tcctggggatccc-aggcaaagccatctctgctttgtgtctaggatgaacaggaggaagaagaggccttcaaccagaaacatgcactgcagaa
6	-------tcctggggatccc-aggcaaagccatctctgctttgtgtctaggatgaacaggaggaagaagaggccttcaaccagaaacatgcactgcagaa
7	-------ttatggggaccct-agtcacagccatgtctgctttgtatctaggatgagcaagaggaagaggaagccttcaaccagaaacatgcactacagaa
8	-------------------c-tggctaagctgcctctgcttcat-tctaggatgagcaggaagaagaggaggccttcaaccaaaagcatgccctgcagaa
9	-------ttatgaggatcct-gggcaaagtcatctctgctttgtatctaggatgaacaggaagaagaggaggccttcaatcagaaacacgcactgcagaa
10	-------tcatggggatcct-gggcaaaggcacctctgctttatgtctaggatgagcaggaggaagaggaggccttcaaccagaagcacgcactgcagaa
11	-------tcagagagattcc-aggcaaagctatctctattttatgtctaggatgagcaggaggaagaagaggccttcaaccagaaacatgcactgcagaa
12	-------ttgttgcaacctt-aggtaaagctatctttgttttgtgcctaggatgagcaggaggaagaagaagccttcaaccagaaacatgcactgcagaa
13	-------ctatggcaattct-aggtaaagctatctctgttttgtgtctaggatgagcaggaggaagaagaagccttcaaccagaaacatgcactgcagaa
14	-------ccatggagatccc-aagcaaaaccatctctgctttgtgtctaggatgaacaggaagaagaagaagccttcaaccagaaacatgcactacagaa
15	-------tcacagggatccc-agacaaagtcatctctgctttgtgtctaggatgagcaggaggaagaagaggccttcaaccagaaacatgcactgcagaa
17	-------tcatggggatccg-aagcaaagccatctctgctttatgtctaggatgaacaggaagaagaggaggccttcaaccagaagcatgcactgcagaa
18	-------tcatgggaatccc-agacaaagccatctctcctttatgtctaggatgaacaggaagaagaagaggccttcaaccagaaacatgctctgcagaa
19	-------ccggggagaacca-aggcaaagccctctctgctctgtgtctaggatgaacaggaggaagaagaggccttcaaccagaaacacgcgctgcagaa
20	-------acaggg--ctcaa-aggagaaaccctctttgttttgtgtctaggatgagcaggaggaggaagaggccttcaaccagaagcatgcgctacagaa
22	ccttttgttgtatggaacac-aggcaaaaccatctctgctttgtgtctaggatgagcaggaagaagaggaagccttcaaccagaagcacgcacttcagaa
24	-------tcatggggatccc-agacaacgccatctctactttgtgtctaggatgaacaagaagaagaggaggccttcaaccagaagcatgcactgcagaa
25	-------tcacagggattcc-aggccagtccctctctgctttgtctctaggatgagcaggaagaagaggaggctttcaaccagaagcacgccctgcagaa
26	-------tcatggggatccc-aggcaaagccatctctgctttgtgtctaggatgagcaagaagaagaggaggctttcaaccagaaacatgcattgcagaa
27	-------tcacagggatccc-aggcaaagccatctctgctttgtgtctaggatgagcaggaagaagaggaggccttcaaccagaaacatgcactgcagaa
28	-------tcatggagatccc-aggcaaaaccatttctactttgtgtccaggatgagcaggaggaagaggaggccttcaaccagaaacatgcactgcagaa
29	-------tcatggcgatctt-aggcaaagccatctctgctttgtatctaggatgagcaggaggaagaggaagccttcaaccagaaacatgcattgcagaa
30	-------ccctggggattcc-aggcaaagccacttcttctttgtgtttaggatgagcaggaggaagaggaggccttcaaccagaaacatgcgctgcagaa
31	-------ttatgagaattct-aggaaaagctctgtctgctttgtgtctaggatgaacaggaggaagaggaggccttcaaccagaagcatgccctacagaa


y=1 OE:	dss	chr1	180194393	180194393	+	0
1	tgtcctctggctctggtctagccacaacagggtcaacgctcgccttgcaggtaaggaagg-gccatccctaag---------gctggagtcacctgt---
2	tgttctctggctctggtctagccacaacagggtcaatgctcgccttgcaggtaaggaagg-gccatccccaag---------gctggagtcacctgt---
5	tgtcctctggctctggtctagccacaacagggtcaatgctcgccttgcaggtaaggaagg-accatccccaag---------gctggagtcacttgt---
8	cgtcctctggctctggaatagccacaaccaggtcaacgctcgcctcgcaggtaaggaggg-gcc---------------------------accagc---
15	ggttctctggctctggaccagccacaacaaggttaatgctcgcctctcaggtaagcctt------------ag---------gctggag-----------
22	tgttctctggctctggtccagccacaacagggtcaataatcgccttgcaggtaagga-gaggccgcctccaagcctggagcc------------tacaga


y=1 OE:	dss	chr1	181771385	181771385	+	0
3	cggcacaacaacttccggagtttctttgggtccctaatgctactcttcaggtacctagatgcgtaactgtcatagctggggttctcctgatg--gag-gg
4	cggcacaacaacttccggagtttctttgggtccctaatgctactcttcaggtacctggatgcgtaactgtcatagctggggttctcctgatg--gag-gg
5	cggcacaacaacttccggagtttctttgggtccctaatgctactcttcaggtacctggatgcgtaactgtcatagctggggttctcctgatg--gag-gg
10	cggcacaacaatttccggagtttctttggatccctcatgttgctcttcaggtaccaggatgtgaaa-tgtcatagagagagtcctgctaatg--ggg-gg
17	cggcacaacaacttccggagtttctttgggtccctcatgctactcttcaggtacttggatacgtaactgttctatctgaagc-ctcttgaca--gaggga
22	cggcacaacaacttccggagcttctttggatctctcatgcttctcttcaggtacc----------accatcatggctggactactcctgcccag------
31	cggcacaacaacttccgaagtttcttcgggtccctcatgctgctcttcaggtacttgggtgtgaaagggttacagccggagccctctccata--aag-gg


y=1 OE:	dss	chr1	180087718	180087718	+	0
0	tcttcagcttctgaaaaacccaagatcaagcccctt---ccattacacaggtagaaatttttgataacttacctagaggtgtgccttgtttgaaaagag-
1	tcctcagcttctgaaaaacccaagatcaaacccctcacaccactacacaggtagaaatttttgataac-tgtctgta-ttctgccttgtttggaaaagg-
2	tcctcagcttctgaaaaacccaagatcaaacccctcacaccactacacaggtagaaatttttgataacttgtctgta-ttctgccttgtttgaaaaagg-
3	tcctcagcttctgaaaaacccaagatcaaacccctcacaccactacacaggtagaaatttttgataacttgtctgta-ttctgccttgtttgaaaaagg-
4	tcctcagcttctgaaaaacccaagatcaaacctctcacaccactacacaggtagaaatttttgataacttgtctgta-ttctgccttgtttgaaaaagg-
5	tcctcagcttctgaaaaacccaagatcaaacccctcacaccactacacaggtagaaatttttgataacttgtctgta-ttctgccttgtttgaaaaagg-
6	tcctcagcttctgaaaaacccaagatcaaacccctcacaccactacacaggtagaaatttttgataacttgtctgta-ttcttccttgtttgaaaaagg-
7	tccgcagcttctgaaaaacccaagatcaagcccatc---ccactacacaggtagaaactgttgataacttgtttata-ttctgcctcacttgggaaaag-
8	tcttcagcttccgagaagccgcggatcaaacccctg---ccgctgcacaggtactcctctctgctggcttctctgtg--tcggccgtgtctggaagaag-
9	tcttcaggttctgagaaacccaagatcaagcccctt---ccactgcacaggtaggaatttcagata-----tctatg-ttctgctttgt-tgag-aagg-
10	tctacagcttctgaaaagcccaagatcaagccccct---ccactacacaggtaggaatt-----------------a-ttcttttttgtataag-gaag-
11	tccacagtttctgaaaaacctaagatcaagcctcct---ccactacacaggtaggaatttttaataacttatttgta-ttccatcttatttgag-aaa--
12	tcctccatatctgaaaaacccaaaatcaagccacat---ccgctacacaggtaagaactgtaaa-aacttacatgta-ttctgct-tatttgat-aatg-
13	tcctccgtatccgaaaaacccaaaatcaagccacac---ccactacacaggtaagaacttttaa-aacttacatata-tactgatttatttgat-aatg-
14	tcctctgtttctgaaaaacccaagatcaagtccctt---ccactacacaggtaggaatttttgacagcttatctata-ttctgctttgtttgag-aaag-
15	ccctcagtttctgaaaaacccaagatcaagtccctt---ccactgcacaggtaagaaattttgacaacttatgtata-tttccccttgtttaag-aaag-
17	tcctcagcttctgaaaaacccaagatcaagcccctc---ccactacacaggtaggaatttatgataacttatct--a-gtctgcctggtttgag-aaag-
18	tcgtcagcatctgagaagcccaagatcaaagccctt---cctctacacaggtagggatcttt-ataacttagctatt-ttctgcctgctttgag-aaag-
19	tccacagcttctgaaaaacccaagatcaagcccctt---ccacttcacaggtagacagttctgataacttacctata-ttctacctcattggagaagag-
20	tcttcagcttctgaaaaacccaagatcaagcccctt---ccactacacaggtagaaaattttgatgacttacctata-ttctgccttgtttgaggaaat-
22	tcatcagcttctgaaaaacccaagatcaagtccctt---ccactacacaggtagaaatattttataacttacctgta-ttctattttgcttaggaaaag-
23	tcctcagcttctgaaaaacccaagatcaagcccctt---ccattgcacaggtagacacttgtggtaacttatttata-ttctgccttgtttgagaaaag-
24	tcctcaacttctgaaaaacccaagatcaagtccctt---ccactgcacaggtagaaatt-ttgataactaacctata-tcctgccttatttgcaaaaga-
25	tcctcagcttctgaaaaacccaagatcaagcccctt---ccactacacaggtagaaaattttgata----acgtata-ttctgctttatatgagaaagg-
26	tcctcagcttctgaaaaacccaagatcaagcccctt---ccattacacaggtagaaatttgtgataacttatctata-ttctgccctgtttgaga--agt
27	tcctcagcttctgaaaaacccaagatcaagcccctt---ccactacacaggtagaaatttttgacaacttacctata-ttctgccttgtttgagaaaag-
28	tcctcatcttctgaaaaacccaagatcaagccccta---cccctgcacaggtagagatttttgataactaagctata-ttctgccttgtttttaaaaag-
29	tcctcagcttctgaaaaacccaagatcaagcccctt---ccactacacaggtagaattttatgataacttatctata-ttctgccttgtttgagaaaac-
31	tcctcaacttctgaaaagcccaagatcaagcccctc---ccactacacaggtagaaattttttataatttacctata-ttctgccttgtttgagaaaag-


y=1 OE:	dss	chr1	180053167	180053167	+	0
0	atgaagaag---cttccccagaaaagactactacactgtcttctaccaaggtgtgtttcg-g-tttatct-ag-g-ca--gg-t-------gaat----g
1	atgaagaag---cttctccagaaaaaac---tacgctgtctactgccaaggtgtgtttca-c-tttatgt-gt-g-ga--gg-t-------aaat----g
2	atgaagaag---cttctccagaaaaaac---tacactgtctactgccaaggtgtgtttca-c-tttatct-gt-g-ga--gg-t-------aaat----g
3	atgaagaag---cttctccagaaaaaac---tacactgtctactgccaaggtgtgtttca-c-tttatct-gt-g-ga--gg-t-------aaat----g
4	atgaagaag---cttctccagaaaaaac---tacactgtctactgccaaggtgtgtttca-c-tttatct-gt-g-ga--gg-t-------aaat----g
5	atgaagaag---cttctccagaaaaaac---tacactgtctactgccaaggtgtgtttca-c-tttatct-gt-g-ga--gg-t-------aaat----g
6	atgaagaag---cttctccagaaaaaac---tacactgtctactgccaaggtgtgtttca-c-tttatct-gt-g-ga--gg-t-------aaat----g
7	atgaagaagaaaagtccccagagaagac---tacactgtcttctgccaaggtatgtttca-t-gttacct-ct-g-gaaggg-t-------gtgt----a
8	atgaggaag---cctccccagagaagac---ctcgctgtcttctgccaaggtgggttttt---ctttccc-at-a-------------------------
9	aagaagaag---cttccccagataaaac---tacattgaattctgccaaggtgtgt--------tggcct--c-a-aa--g-------------------
11	atgaagacg---cttccccagacaagac---tacgctgtcttctaccaaggtctgtttct-g-tttgctt--c-a-aa--g-------------------
12	atgaagatg---cttccccagacaagac---tacactgtgttctaccaaggtatgtttt------tactc--g-g-----gg-t-------aaat----g
13	atgaggatg---cttccccagacaagac---tgctctgtcttctaccaaggtgcgcttt------tacta--a-g-ga--gg-c-------tcat----g
15	atgaggaag---cgtccccagacaaaac---tgcattgtcttcagccaaggtgtgttctc-g-ttgaccc--atg-ga--gg-t-------cggt----g
17	atgaagaag---cttccccagacaagac---cacactgtcttctgccaaggtgtgtttcc-g-tttgccta-t-g-ga--gg-t-------aaat----g
19	acgaggaaa---cttccccagagaagac---tacactgtcttctgccaaggtgtgtttct-t-t-tacct-gt-a-ga--ag-tacttcatgatggttgt
20	atgaagaac---cttccccagaaaagac---tgcattgtcttctgccaaagtatgtttcagt-t-tacct-ct-a-ga--gg-tagttcagta-------
22	atgaagaaa---tttctccagaaaagac---cacattatcttctgccaaggtatgtttta-gtt-tatca-gt-g--a--gg-tacttaatatt------
23	acgaagaga---cctccccagaaaagac---tacactgtcttctgccaaggtgggtgtcg-gtt-tagct-ag-a-ca--gg-tgcttcaggcgt----a
24	atgaagaaa---cttctccagaaaagac---taccctgtcctctgccaaggtgtgtttta-gtt-taccc-at-g-ga--ga-tacttcatatat----a
26	atgatgaaa---cctctccagaaaagac---aacactgtcttctgccaaggtgcgcttca-gtt-tacct-gt-g-ga--atttacttcataaat----a
27	atgaagaaa---cttccccagaaaagac---tacactgtcttctgccaaggtgtgtttca-gtt-tacct-gt-g-gg--ag-ttcttcataaat----a
28	atgaagaag---cttccccagaaaagac---cacactgtcttctgtcaaggtgtgtttta-g-tttacct-gt-ggga--gg-tatttcataaat----g
29	atgaggaag---cctccccagaaaagac---tacactgtcctctgtcaaggtgtgtt-ta-g-tttacct-gt-g-ga--ag-tactccatacat----g
30	atgaagaag---cttccccagaaaagac---tccactgacctctggcaaggtatgtgtta-g-tttacc-----a-ga--ag-ttcttcacaa-t----g
31	atgaggagg---cttccccagaaaagac---gacactgtcctctgtcaaggtgtgtttta-g-tttacct-gt-g-aa--aa-ttcttgataaat----g


y=1 OE:	ass	chr1	181717092	181717092	+	0
0	-tcctc-c--ttata-tcttttctttc--cc-c--t--t---------aggcacacctcttgcccgagccagtatcaaaagctcaaaggtagacggggcc
2	-t---c-c--ttact-t-----ct-cc--cc-c--t--t---------aggcacacctctggcccgagccagtatcaaaagtgcaaaggtagacggggtc
3	-t---c-c--ttact-t-----ct-cc--cc-c--t--t---------aggcacacctctggcccgagccagtatcaaaagtgcaaaggtagatggggtc
4	-t---c-c--ttact-t-----ct-cc--ct-c--t--t---------aggcacacctctggcccgagccagtatcaaaagtgcaaaggtagatggggtc
5	-t---c-c--ttact-t-----ct-cc--ct-c--t--t---------aggcacacctctggcccgagccagtatcaaaagtgcaaaggtagacggggtc
6	-t---c-c--ttact-t-----ct-cc--cg-c--t--t---------aggcacacctctggcccgagccagtatcaaaagtgcaaaggtagacggggtc
7	-tcgtt-c--tttca-t-----ct-tc--cctgc-c--t---------aggtacacctcttgcccgagcaagtatcaaaagcacaaaggtagacggggct
8	-tactc-cttccctc-t-----t---c--ccc---t--c---------aggcacccctcttgcccgagccagcatcaagagtgcgaaggtggatggggcc
9	-ttccc-c--tcctt-t-----c---c--cc-tc-t--t---------aggtacaccgcttgcccgagccagcatcaagagcacaaaggtagatggggcc
10	-tcttc-c--tgatt-t-----c---c--cc-cc-accc---------aggcacaccgcttgcccgagccagtatcaagagcacaaaagtagatggagct
11	-tccta-t--tcatt-t-----t---t--cc-tc-ccct---------aggcacaccacttgcgcgagccagcatcaagagcacaaaggttgatggagct
12	-tcctc------atttc-----c---c--tt-ca-t--t---------aggcacacctcttgccagagccagtatcaagagcacaaaagtagatggagcc
13	-tcctc------atttc-----c---c--tt-cc-t--t---------aggcacacctcttgccagagccagtatcaagagcacaaaagtagatggggcc
14	-tcctt------atttc-----c---c--tt-cc-t--t---------aggcacaccgcttgcccgagccagtatcaagagcacaaaagtagatggagcc
15	-tgctt------atttc-----c---c--tc-cc-t--c---------aggcacacctcttgccagagccagtatcaagagcacaaaggtagacggggcc
17	-tcctc-c--tcgtt-t-----c---c--cc-cgct--t---------aggtacgcctctcgctcgagccagtatcaagagcacaaaagtagatggggcc
18	-tcgtc-c--ttatt-t-----c---c--cc-aa-t--c---------aggcacacctctcgcccgagccagcatcaagagtaccaaggtagatggagcc
19	t----c-t--tgcca-t-----tg-----ct-cc-a--c---------aggcactcctcttgcccgaggcagcatcaaaagtgcgaaggtggatggggcc
20	t----c-t--c---------------------cc-c--c---------aggcacccctcttgcccgcgccagcatcaagagtaccaaggtggacggggcc
22	t----c-a--ttctt-c-----ct-----tc-ct----cttcacccccaggcactcctctggcccgggccagcatcaaaagtgcaaaggtggacggggcc
24	c----t-c--cttcc-t-----tc-tccctt-gc----t---------aggcacacctctcgcccgagccagcatcaagagcgccaaggtggacggggcc
25	t----t-c--cttcc-t-----cc-tgcctc-tg----t---------aggcacacctctcgcccgagccagcatcaaaagcgcgaaggtggatggggcc
26	-------c--cttcc-t-----tc-tct-cc-cc-t--t---------aggcacccctctcgcccgagccagcatcaaaagtacaaaggtggacggggcc
27	c----t-c--cttac-t-----tc-tcc-ctgc--t--t---------aggcacacctcttgcccgagccagcatcaagagtgccaaagtggacggggcc
28	-tcctt-c--ttctt-t-----ca-tc--cc-ccac--c---------aggcactcctcttgcccgagcaagtatcaaaagtgcaaaggtggacggggcc
29	-tcctc-c------t-t-----ct-c---cc-cc-t--c---------aggcacgcctcttgcccgagccagcatcaaaagtgccaaggtggatggagcc
30	-tcctct---cttct-c-----ct-cc--cc-cc-t--c---------aggcacacctctggcccgagctagtatcaaaagtgccaaggtggacggggcc
31	-tgcttt---ttgtt-t-----cttct--tc-tc-t--c---------aggcacaccgctcgctcgagctagtatcaaaagtgccaaggtagatggggcc


y=1 OE:	ass	chr1	181784660	181784660	+	0
0	-ctgatt-t----attt--att-tataattt-a---tcttattg---taggcggtgcagacaggcagcagttagactcagagctgcagaaggagaccctg
1	-c------t----attt--att-agtaattt-a---tcttattc---taggtggtgcagacaggcagcagctagactcagagctacaaaaggagacccta
2	-c------t----attt--att-agtaattt-a---tcttattc---taggtggtgcagacaggcagcagctagactcagagctacaaaaggagacccta
3	-c------t----attt--att-agtaattt-a---tcttattc---taggtggtgcagacaggcagcagctagactcagagctacaaaaggagacccta
4	-c------t----attt--att-agtaattt-a---tcttattc---taggtggtgcagacaggcagcagctagactcagagctacaaaaggagacccta
5	-c------t----attt--att-agtaattt-a---tcttattc---taggtggtgcagacaggcagcagctagactcagagctacaaaaggagacccta
6	-c------t----attt--att-agtaattt-a---tcttattc---taggtggtgcagacaggcagcagctagactcagagctacaaaaggagacccta
7	-ctgatttt----attt--att-aataattt-a---tcttattc---taggtggtgcagacaggcagcagctagattcggaactgcagaaagagaccctg
9	-ccaatt-c----acgc--att-aataattt-c---tcttattc---taggtggtgcagacaggcagcagctagactcggagctacagaaggagacgctg
10	-ccaatg-t----attt--atc-agtaatgt-a---tctcgttc---taggtggtgcagacaggcagcagctagactcagagctacaaaaggagaccctg
13	-ctgatt-g----ggtt--att-aataattt-a---tcttattc---taggtggtgcagacagacagcagctagactcggagctgcaaaaagagaccctg
14	-ctgatt-g----gctt--att-aataattt-c---tcttattc---taggtggtgcagacagacagcagctagactcagagctacaaaaagagaccctg
15	-ctaatt-tt---tttt--att-actaattt-a---tcttgttt---taggtggtgcagacagacagcagctagactcagagctacaaaaggagaccctg
17	-ctgatt---------t--att-aatgattt-a---tcgtattt---taggtggtgcagacaggcaacagctagactcagagctgcaaaaggagaccctg
18	-ctgatt-t----acgt--att-aataattg-a---tcttattc---taggtggtgcagacaggcagcagctagactcagagctacaaaaggagacccta
22	c-------tgagt------att-aataactg-ttcttat---cc---taggtggtgcggacaggcagcagctagactcagagctccaaaaggagaccctg
24	t-------t----cgtt--gtt-aatgaatgta---tct---tctcccaggcggtgcagacaggcagcagctagactcagagctccagaaggagaccctg
25	t-------t----ggct--gtt-aatgactc-a---tct---catcctaggtggtgcagacaggcagcagctagactcggagctgcagaaggagaccctg
26	c-------t----atttattaa-aatttatc-t---------tc---taggtggtgcagacagacagcagctagactcagagctacaaaaggagaccctg
27	t-------t----atttattaataatttttc-t---tac---tc---taggtggtgcagacaggcagcagctagacgcagagctacaaaaggaaaccctg
31	--------t----gttt--att-aacaatat-c---tcttattc---caggtggtgcagacaggcagcagctagattcagagctacaaaaggagaccctg


y=1 OE:	dss	chr1	181720856	181720856	+	0
0	cttcagcaaattttgataccttcccggcagccattatgactgtatttcaggtatgaggc----c-aacagaca-------gtctagac-tgctg---tgc
1	cttcggcaaattttgacaccttccctgcagccatcatgaccgtgttccaggtatgaggc----c-agctgacg-------gttcacaagtgctg---cgt
2	cttcggcaaattttgacaccttccctgcagccatcatgaccgtgttccaggtatgaggc----c-agctgaca-------gttcacaagtgctg---cat
3	cttcagcaaattttgataccttccctgcagccatcatgaccgtgttccaggtatgaggc----c-agctgacg-------gttcacaagtgctg---cat
4	cttcggcaaattttgataccttccctgcagccatcatgaccgtgttccaggtatgaggc----c-agctgacg-------gttcacaagtgctg---cat
5	cttcggcaaattttgataccttccctgcagccatcatgactgtgttccaggtatgaggc----c-agctgacg-------gttcacaagtgctg---cat
6	cttcggcaaattttgacaccttccctgcagccatcatgaccgtgttccaggtatgaggc----c-agctgatg-------gttcacaagtgctg---cat
7	cttcagcaaactttgataccttccctgccgccatcatgactgtgttccaggtatgagct----c-acacagca-------gtccagagatgata---tgt
8	cctcagcaaactttgacacttttcctgctgccatcatgactgtgttccaggtataaggc----c-atctgcc----------------------------
9	cttcggcaaattttgatacctttcctgcagccatcatgacggtgttccaggtataaggc----c--actgaca-------gttcagataggcta---tga
11	cttcagcaaattttgatactttccctgcagccatcatgactgtgttccaggtatgaggctaac-------aga-------gtctagaaatgctg---tat
12	cttcggctaattttgataccttccctgcagctatcatgacagtgttccaggtatgaggc----ca-actgata-------gctcagaagtgtta---tgt
13	cttcagctaattttgacaccttccctgcagctatcatgacagtgttccaggtatgaggc----ca-actgata-------gctcagaagcacta---tgt
14	cttcagcaaattttgataccttccctgcagctatcatgactgtgttccaggtatgaggt----ta-actgaca-------atctggaaatgcta---tgt
15	cttctgctaattttgacaccttcccggcggcaatcatgactgtgttccaggtatgtgc------------aca-------gtctagaaatgcta---cgt
17	cttctgcaaattttgatacctttcctgcagccatcatgactgtgttccaggtatgaggt---------tgata-------atccagaaatgctg---t--
18	cttcagcaaattttgataccttccctgcggctatcatgactgtgttccaggtaagaagc----ta-cctgata-------gttcagaaatgcta---cat
19	cttcagccaactttgacaccttccctgcagccatcatgactgtattccaggtaggaag------------aag-------attaaaaaatgtcc---ctt
20	cttcagccaactttgacacctttcctgcagccatcatgactgtgttccaggtaagaag------------ctg-------atcga---------------
22	cttcggcaaactttgacactttccctgcagccatcatgactgtattccaggtatgagg------------ccaactggcagttaaagaacacca---tgt
24	cttccgcaaactttgacaccttccctgcagccatcatgactgtattccaggtatgagg------------atg-------tt--aaaaatgtta---ctt
25	cttcagccaacttcgacaccttccctgcagccatcatgactgtcttccaggtatgagg-------------tc-------cctaaagcatgttc---tgg
26	cttcggcaaactttgacaccttcccagcagccatcatgaccgtattccaggtatgaga------------ccaactggcagttaa-aaatatta---tgt
27	cttcagcaaactttgacaccttcccagcagccatcatgactgtattccaggtataagg------------ccaactagcagttaa-aaatgtga---tgt
31	catctgcaaattttgacacctttcctgcagccatcatgactgtatttcaggtatgagac----c-aaatgaaa-------tttaaaaaaaatatgaatat


y=1 OE:	dss	chr1	181737655	181737655	+	0
0	tcgccctggcggcagaggaccctgtcctgaccaactcggagcgcaacagggtgggtgctc-ag---------g------gtcc-acttgccaacctctac
4	tcgccctggcggcagaggaccccgtcctgaccaactcggagcgcaacaaagtgggtacac-ag---------g------ggcc-atgtgccagcctctgt
5	tcgccctggcggcagaggaccccgtcctgaccaactcggagcgcaacaaagtgggtacac-ag---------g------ggcc-atgtgccagcctctgt
6	tcgccttggcggcagaggaccccgtccttaccaactcggagcgcaacaaagtgggtacac-ag---------g------ggcc-atgtgccagcctccgt
7	tcgccctggccgcagaggaccctgtcctgaccaattcggagcgcaacaaagtgggtgccc-ag---------g------ggcc-tttggccaatgctagt
8	tcgccctggcagctgaggaccccgtgctgaccaactcggagcgcaacagagtgcgtgcat-gg---------c---------------------------
9	ttgccctcgcagcagaggaccctgtcttaaccaactcagatcgcaacaaagtaggtgtgc-ag---------g------g-cc-ctttgccagcttctga
10	ttgccctggcagcagaggacccagtcctgaccaactcggaacgcaacaaagtgggtgcac-ag---------g------ggcc-atttgtccacctgtga
11	ttgccctggcggcagaggacccagtcctgaccaactcggagcgcaacaaagtgggtgcct-ag---------g------ggct-gctggtcatcctccga
12	ttgccctggcagctgaggaccctgtactaactaactcagagcgtaacaaagtgagtactt-ggg--------g------ggca-gtttgccaacattctt
13	ttgccctggcagccgaggaccctgtactaactaactcggagcgtaacaaagtgggtacac-ggttgggggggg------cggg-atttgccaatattgtt
14	ttgccctggcagctgaggaccctgtcttgaccaactcagaacgcaacaaagtgggtgtat-ag---------g------gacc-aatttccaatcctcct
15	tcgccctggcagcagaggaccctgtcctgaccaactcggagcgcaacaaagtgggtacac-agtg-------g------gccc-atttgtcaacctt-gt
17	ttgccctggccgcggaggaccctgtcctgaccaactcggagcgcaacaaagtaggtgtac-gg---------g------ggcc-atttgctgatctctgt
18	ttgccctggcagctgaggaccccgtcctgaccaactcggagcgcaataaggtgggtgcac-ag---------a------ggcc-attggctgacat-tgc
19	tcgccctggcagccgaggaccctgtgctgaccaactcagagcgcaacaaagtgggtacag--g---------g------ggca--cttgccac---ccca
20	tcgccctggccgctgaggaccccgtcctcaccaactcagagcgcaacagagtgggt------------------------------ttcccat---ccc-
22	tcgccctggcagctgaggacccagtcctgaccaactcagagcgtaacaaagtgggtg-------------------------------------------
24	tcgccctggcggccgaggaccccgtcctgaccaactcagagcgcaacaaagtgcgtgcacg-g---------g------ggct-gtctgccagcctccac
25	tcgccctggcggccgaggaccccgtcctgaccaactcggagcgcaacaaagtgggtgctca-g---------a------tgct-gctggccagcctccgt
26	tcgccctggcagccgaggaccccgtcctgaccaactccgagcgcaacaaagtgggtgcatg-g---------gagccga-gcc-at-cag----------
27	ttgccctggcggccgaggaccctgtcctgaccaactcggagcgcaacaaagtgggtgcaca-g---------g------ggcc-attttccagcctcgat
28	ttgccctggcagctgaagaccctgtcctgaccaactccgagcgcaacaaagtgggtgccc-ag---------g------ggcc-attgaccagccttctt
29	ttgccctggctgctgaggaccccgtcctgaccaactccgagcgaaacaaagtgggtgcac-gg----------------ggct--ctaaacaacctccat
30	tcgccctcgccgccgaagaccctgtcctcaccaactccgagcgcaacaaagtgggttcac-ag---------g------gcccaagtgtccgacctccat
31	tagccctggcggcagaggaccctgttctgaccaactccgagcgcaacaaagtgggtgc-c-tg---------g------ggcc-atttaccagcctctgt


y=1 OE:	dss	chr1	180031495	180031495	+	0
0	actcttgactctgatagcactttggagggtctttctggtcattctgtgaggtaaagt-aa---------tatat---------act-tt-attc-tgta-
1	actcttgatacagatagcactttggaagatctttctggacattctgtgaggtaaagttaa---------tgtgt---------gct-tt-atac-tgta-
2	actcttgatacagatggcactttggaggatctttctggacattctgtgaggtaaagt-aa---------tgtat---------att-tt-atac-tgta-
4	actcttgatacagatagcactttggaggatctttctggacattctgtgaggt------aa---------tgtat---------att-tt-atac-tgta-
5	actcttgatacagatagcactttggaggatctttctggacattctgtgaggt------aa---------tgtat---------att-tt-atac-tgta-
6	actcttgatacagatagcactttggaggatctttctggacattctgtgaggt------aa---------tgtat---------att-tt-atac-tgta-
7	acacttgataccgatagcactttggagaatctttctgggcattctatgaggtaaagt-aa---------tatat---------att-tt-atag-tgta-
8	actctcgacactgaaagcactttggaggaactttctgggccttctctgaggtaacat-ac---------tgtaa---------tct-tt-atac-ttta-
9	actcttgacactgacagcactttagaagaactttctgggcattctgtgaggtaa---------------tgtcc---------att-tt-atac-tgta-
10	actctcgacactgatagtactttggaagaactttctggacattctgtgaggtaatgt-aatgtatttgt---ctttgggta--tt--ta-atac-tcta-
11	actctcgacactgatagcactttggaagaactttctgggcattctgtgaggtaaagt-aatgtatttat---cctttttaatgctt-tt-atat-tgta-
12	actctggatgctgagagcacgttggaagaactttctgggcattctgtgaggtaaagc-ag---------catat---------tct-tt-atg----taa
13	actctggatgctgagagcacactggaagacctgtctgggcactctgtgaggtaaagc-cc---------tggat---------tct-tt-atgc-tgcta
15	actttcgacactgatagcactttggaagaactttctgggtattctgtgaggtaaagt-aa---------tacat---------tct-tc-atgc-tgtg-
16	atttttgatactgaaagcactttagaagaactttctgggcactctgtgaggtaat----------------------------att-tt-atat-tttg-
17	actcttgacattgatagcactttggaagaactttctgggcattctgtgaggtaaagt-aa---------tgtat---------gct-tt-atac-tgta-
19	attcttgacaccgatagtactttggaggatctttctgggcattctgtgaggtatatc-aa---------tgtac---------att-tt-atac-tata-
20	acttttgacactgacagcactttggaggatgtttctggtcattcactgaggtatagt-aa---------tgcat---------att-tt-atac-tata-
22	gctcttgacacagataacaccttggaggatctttctgggcgttctgtgaggtatagt-aa---------tatat---------att-ta-atgc-tata-
23	actctcgacactgatagcactttggaggatcttt---------ctgggaggtaat---aa---------tgtat---------gtt-tt-atac-tgtg-
24	actcttgataccgatagcactttggaagaaatttctgggcattctttgaggtaaagt-ta---------tgcat---------att-tt-atac-tgga-
25	actcttgacactgatagcactttggaggatctttctgggcattctttgaggtaaaat-aa---------tgtat---------att-tt-atat-tgtc-
26	actcttgacactgatagcattttgcaggatctttctgggcattctgtaaggta------a---------tgtat---------att-tt-atacctgta-
27	actcttgacaccgatagtactttggaggatctttctgggccttctttaaggtaaagt-aa---------tgtat---------att-tt-atac-taga-
28	actcttgatactgatagcactttggaggatctttctggtcattctgtgaggtaaagt-aa---------tgtac---------att-tt-atat-tata-
29	acccctaatgatgagagcatgttggaggatcagtctggacattctgtgaggtaaaat-ga---------tatgt---------gtt-tt-atac-tgta-
30	actcttgacactgacagcatattagaggatctttctggacattctgtgaggt------aa---------tgtat---------agtttat--ac-ggta-
31	actctagacaccgagagcatattggaggatctctctggacactctgtgaggtaaagg-aa---------tgtgt---------ttt-ta-g-ac-tgtg-


y=1 OE:	ass	chr1	181783678	181783678	+	0
0	---gcctgctgt--ttt-c--t--t-------tttctcttt--cacacagaggttggtcttgatgaatatgccggtagctgaggacatgacagtccactt
1	---gtctgctgt--ttc-t--t--t-------tttctcttt--cacacagaggttggtcctgatgaacatgccagtagctgaggacatgacggtccactt
3	---gcctgctgt--ttc-t--t--t-------tttctcttt--cacacagaggttggtcctaatgaacatgccagtagctgaggacatgacggtccactt
4	---gcctgctgt--ttc-t--t--t-------tttctcttt--cacacagaggttggtcctgatgaacatgccagtagctgaggacatgacggtccactt
5	---gcctgctgt--ttc-t--t--t-------tttctcttt--cacacagaggttggtcctgatgaacatgccagtagctgaggacatgacggtccactt
6	---gcctgctgt--ttc-t--t--t-------tttctcttt--cacacagaggttggtcctgatgaacatgccagtagctgaggacatgacggtccactt
7	---gcttgctgt--ttc-t--t--c-------tttctcttt--cacacagaggttggtcctgatgaatatgccagtagctgaggacatgactgtccattt
8	---tccggctct--ttc-t--t----------tttctcttc--cacgcagaggctggtgctcatgaacatgcccgtggccgaggacatgacagtccactt
9	---gcctgctgt--ttt-t--t--tttttctttttctcttt--cacacagaggttggtcctgatgaatatgccagtagccgaggacatgacagtccactt
10	---gcctgctgt--ttc-c--t--t-------tttctcttt--cacacagaggttggtcctgatgaacatgccagtagctgaggatatgactgtccactt
11	---gcctgctgt--ttc-c--t--t-------tttctcttt--cacacagaggttggtcctgatgaacatgcccgtagctgaggacatgaccgtccactt
12	---gcctgctct--ttc-t--c--t-------tttctcttc--cacacagaggttggtcctgatgaatatgccagtggctgaggacatgacagtccattt
13	---gcctgctct--ttc-t--c--t-------tttctcttt--cacacagaggctggtcctgatgaacatgccagtggctgaggacatgacagtccactt
14	---gcctgctgt--ttc-t--c--t-------ttgctcttt--cacacagaggttggtcctgatgaatatgccagtagctgaggacatgacagtccactt
15	---gcctgctgt--ttc-t--c--t-------tttctcttt--tacacagaggttggtcctgatgaatatgcctgtagctgaagacatgacagtccactt
17	---gcctgctg----tt-t--t--t-------ttcttcttt--catacagaggttggtcctgatgaatatgccagtggctgaggacatgacagtccattt
18	---gcctgctgt--ttc-t--t--c-------tttctcttt--cacacagaggttggtcctgatgaatatgccagtagctgaggacatgactgtccactt
19	---tcctgcggc--ctc-t--t-----------ctctctct--cacacagaggttggttctgatgaacatgccagttgccgaggacatgaccgtccactt
20	---tcctgctgctgctg-t--t-----------ctctctct--cacgcagaggttggtcctgatgaatatgccggtggctgaggacatgaccgtccactt
22	---tcctgctgc--tgc-t--ttt---------ctctcttt--cacacagaggttggtcctgatgaacatgcctgtagctgaggacatgactgtccactt
24	---tcctgctgt--ttc-t--t-----------ttctctttttcacacagaggttggtcttgatgaacatgccagtggccgaggacatgaccgtccactt
25	---tcccgctgt--ttc-t--t-----------ttctc--t--cacgcagaggttggtcctgatgaatatgcccgtggctgaggacatgaccgtccactt
26	---tcctgctgt--tttgtttc-----------ctctcttt--cgcacagagattggtcctgatgaatatgccagtggctgaggacatgacggtccactt
27	---tcctgctgt--ttc-tttt-----------ttctcttc--cacacagaggttggtcctgatgaacatgccagtggctgaagacatgacagtccactt
29	---gcctgctat--ttc-t--t--t-------tc--tcttt--cacacagagattggtcctgatgaacatgccggtagctgaggacatgacagtccactt
31	cccgcctgctgt--ttc-t--t--t-------tctctctca--cacacagagattggtgctgatgaacatgccagtggctgaggacatgacagtccactt


y=1 OE:	dss	chr1	180397515	180397515	-	0
0	aggaactagtcacagtcttactacaatgtagagctgatattaactgtcaggtaa--gg---------ga-----t------ga-agag--gtgctttttt
1	aggagctagtcacagtcttgctgcaacatagagctgacattaactgtcaggtaagagt---------gacaaaat------aa-agaa--gagcttt---
2	aggaactagtcacagtcttgctacaacatagagctgacattaactgtcaggtaagagt---------ga-----t------aa-agaa--gagcttt---
3	aggaactagtcacagtcttgctgcaacataaagctgacattaactgtcaggtaagagt---------ga-----t------aa-ggaa--gagcttt---
4	aggaactagtcacagtcttgctgcaacatagagctgacattaactgtcaggtaagagt---------ga-----t------aa-agaa--gagcttt---
5	aggaactagtcacagtgttgctgcaacatagagctgacattaactgtcaggtaagagt---------ga-----t------aa-agaa--gagcttt---
6	aggaactagtcacagtcttgctacaacatagagctgacattaactgtcaggtaagagt---------ga-----t------aa-agaa--gagcttt---
7	aggaactagtcacagtcttgctgaaatacagagctgacgttaattgtaaggtaagaat---------ga-----t------ga-agcg-ggctcttt---
8	aggagctagtcacagtcttcctacagtataaagctgacattaactgtcaggtaggagt---------gg-----t------aa-a---------------
9	aggaactagccacagtcttgatacaatttaaagctgatattaattgtcaggtaagagt---------ga-----t------aa-agag-ggagcttt---
12	aggagctggtgaaagtcttgctacagtgtgaagccggcattaattgtcaggtaagagt---------ac---att------ta-aaa--ggagcttg---
13	aggaactggtgaaagtcttgctacagtatgaagctggcattaattgtcaggtaagagt---------gc---gtt------ta-aaa--ggagcttg---
14	aagagctggtcagagtcttgctacagtatcaagctgatattaattgtcaggtaagagg---------ga---tta------ta-aaa--ggagtttt---
15	aggaactagtcacagtcttgctacagtataaagctgacattaactgtcaggtaagagt---------ga-----ttaaagaaaaaaa--ggagcctt---
17	aggaattagtcacagtcttgctacaatgtaaagctgacattaattgtcaggtaagagt---------ga-----t------aa-agaa-gggccttt---
20	gggacctcgtcacagtcttattacagtacagagctgatattaactgccaggtaaga-g---------gg-----a------ta-cagg-ggagcttt---
22	aagaactagtcacagtcttgttacaatataaagctgatattaattgtcaggtaagagt---------ga-----t------aa-caag-gggacttt---
24	aggaactagtcacagtcttgctacaatatagagctgatattaactgtcaggtaagagcctgaagggtaa-----t------ga-aaag-ggaacatt---
26	aagaactagttacagtcctgctacagtatagagctgatattaactgtcaggtaagact---------ga-----t------ga-agaggggaccttt---
27	aggagctagtcacagtgttgctacaatatagagctgatattaactgtcaggtaagagt---------ga-----t---gatga-agag-ggagcttt---


y=1 OE:	ass	chr1	181755236	181755236	+	0
0	-tcgt---------at-g-ct-gt-ggctc-tt-t-gc-tctgtccacaggctgtctttgactgtgtggtgacttccttgaagaatgtcttcaacatact
1	-tcac---------ac-a-gc-ag-ggctc-tt-t-gc-tctatccacaggctgtcttcgactgcgtggtgacctccttgaagaatgtcttcaacatact
2	-tcac---------ac-a-gc-ag-ggctg-tt-t-gc-tctgtccacaggccgtcttcgactgcgtagtgacctccctgaagaatgtcttcaacatact
3	-tcac---------ac-a-gc-ag-ggctg-tt-t-gc-tctgtccacaggccgtcttcgactgcgtagtgacctccttgaagaatgtcttcaacatact
4	-tcac---------ac-a-gc-ag-ggctg-tt-t-gc-tctgtccacaggccgtcttcgactgcgtagtgacctccttgaagaatgtcttcaacatact
5	-tcac---------ac-a-gc-ag-ggctg-tt-t-gc-tctgtccacaggccgtcttcgactgcgtagtgacctccttgaagaatgtcttcaacatact
6	-tcac---------ac-a-gc-ag-ggctg-tt-t-gc-tctgtccacaggccgtcttcgactgcgtagtgacctccttgaagaatgtcttcaacatact
7	-tcac---------ac-a-ct-gg-gactc-ct-g-gcttctgtccacaggctgtcttcgactgtgtggtgacctccttaaagaatgttttcaacatact
8	-tcac---------ac----c-tg-ggctg-tg-c-ccctct----gtaggccgtgtttgactgcgtggtgacctccctaaagaacgtcttcaacatcct
9	-tcat---------aa-a-cc-ag-ggcca-tc-t-gctgt--tccacaggctgtgttcgactgtgtggtgacctccttgaagaacgtcttcaacatact
10	-tcac---------at-a-ct-ag-ggccc-tt-t-gctgctgtccacaggccgtgttcgactgcgtggtgacctccttgaagaatgtcttcaacatcct
11	-tcac---------ac-a-cc-ag-ggccc-tt-t-gctgttgtccgcaggctgtgttcgactgcgtggtgacctccctgaagaatgtcttcaacatact
12	-tgac---------atga-----g-cac-c-tt-t-gctgccgtctacaggctgtgtttgactgcgtggtgacctccttgaagaatgtcttcaacatact
13	-tgac---------acga-----g-agc-c-tt-t-gctgccgtccacaggctgtgtttgactgcgtggtgacctccttgaagaatgtcttcaacatact
14	-tcac---------ac-a-----c-agc-t-tt-t-gctgctgtccacaggctgtgtttgactgtgtggtgacctccttgaagaatgtcttcaacatcct
15	-tcac---------ac-a-cc-tg-ggt-c-tt-t-gccactgtccacaggctgtgttcgactgtgtggtgacctctttgaagaatgtctttaacatact
17	-tcac---------at-a-cc-ag-ggccc-tt-t-g---ctgtccacaggcagtgttcgactgtgtggtgacctccttgaagaatgtcttcaacatact
18	-tcac---------ac-a-cc-ag-taccc-tg-t-gccgctgtccacaggctgtgtttgactgcgtggtgacctccttgaagaatgtcttcaacatact
19	ctcac---------cc-a--c-ag-ggctg-ct-g-gtttctctccacaggcggtctttgactgtgtggtgacctccttgaagaatgtcttcaacatact
20	cccac---------acaa--c-ag-ggccc-ca-t-gtttc---ccccaggccgtctttgactgtgtggtcacctccttgaagaatgtcttcaacattct
22	ctcacaacgacaaccg-g--c-ag-gtcca-tt------tc-ccccgcaggctgtctttgactgcgtggtgacttccttgaagaatgtcttcaacatact
23	cccac---------ac-c--c-ccgg-ttcc--------tctgtgtacaggccgtctttgactgcgtggtgacctcgctgaagaacgtattcaacatact
24	ctcac---------ac-ac-c-ag-ggctc-tc-tt-cttctgttctcaggctgtctttgactgtgtggtcacctccttgaaaaacgtcttcaacatact
25	ctcac---------cg----c-ag-ggctc-tt-g--attctgtccgcaggctgtcttcgactgtgtggtgacctccttgaaaaacgtcttcaacatact
26	cttac---------a--------g-ggctc-tggg--cttctctttgcaggctgtctttgactgtgtggtaacctccttaaagaatgtcttcaacatcct
27	ctcac---------ag-c--ccag-ggctc-ctta--cttctgtccacaggctgtgttcgactgtgtggtgacctccttgaaaaacgtcttcaacatcct
29	ctcac---------at-g--t----ggctc----t-gctcctgtctacaggctgtttttgactgtgtggtgacctctttgaaaaatgtcttcaacatact
30	cgtac---------ac----c-gg-gactc-tt-t-gcttgtgtctgcaggctgtctttgactgtgtggtgacctccttgaagaacgtcttcaacatact
31	ctcac---------ac-t--c-ca-ggctc-tc-g-gcttctgtccacaggctgtctttgactgtgtggtgacctccctgaagaatgtcttcaatatcct


y=1 OE:	ass	chr1	181755236	181755236	+	0
0	-cgt---------at-g-ct-gt-gg-ctc-tt-t-gc-tctgtccacaggctgtctttgactgtgtggtgacttccttgaagaatgtcttcaacatact
2	-cac---------ac-a-gc-ag-gg-ctg-tt-t-gc-tctgtccacaggccgtcttcgactgcgtagtgacctccctgaagaatgtcttcaacatact
3	-cac---------ac-a-gc-ag-gg-ctg-tt-t-gc-tctgtccacaggccgtcttcgactgcgtagtgacctccttgaagaatgtcttcaacatact
4	-cac---------ac-a-gc-ag-gg-ctg-tt-t-gc-tctgtccacaggccgtcttcgactgcgtagtgacctccttgaagaatgtcttcaacatact
5	-cac---------ac-a-gc-ag-gg-ctg-tt-t-gc-tctgtccacaggccgtcttcgactgcgtagtgacctccttgaagaatgtcttcaacatact
6	-cac---------ac-a-gc-ag-gg-ctg-tt-t-gc-tctgtccacaggccgtcttcgactgcgtagtgacctccttgaagaatgtcttcaacatact
7	-cac---------ac-a-ct-gg-ga-ctc-ct-g-gcttctgtccacaggctgtcttcgactgtgtggtgacctccttaaagaatgttttcaacatact
8	-cac---------ac----c-tg-gg-ctg-tg-c-ccctct----gtaggccgtgtttgactgcgtggtgacctccctaaagaacgtcttcaacatcct
9	-cat---------aa-a-cc-ag-gg-cca-tc-t-gctgt--tccacaggctgtgttcgactgtgtggtgacctccttgaagaacgtcttcaacatact
11	-cac---------ac-a-cc-ag-gg-ccc-tt-t-gctgttgtccgcaggctgtgttcgactgcgtggtgacctccctgaagaatgtcttcaacatact
12	-gac---------atga-----g-ca-c-c-tt-t-gctgccgtctacaggctgtgtttgactgcgtggtgacctccttgaagaatgtcttcaacatact
13	-gac---------acga-----g-ag-c-c-tt-t-gctgccgtccacaggctgtgtttgactgcgtggtgacctccttgaagaatgtcttcaacatact
14	-cac---------ac-a-----c-ag-c-t-tt-t-gctgctgtccacaggctgtgtttgactgtgtggtgacctccttgaagaatgtcttcaacatcct
15	-cac---------ac-a-cc-tg-gg-t-c-tt-t-gccactgtccacaggctgtgttcgactgtgtggtgacctctttgaagaatgtctttaacatact
16	-cac---------ac-a-cc-ag-gg-t-c-tt-c-actgatgttcacaggctgtattcgactgtgtggtgacttctttgaagaatgtcttcaatatact
17	-cac---------at-a-cc-ag-gg-ccc-tt-t-g---ctgtccacaggcagtgttcgactgtgtggtgacctccttgaagaatgtcttcaacatact
18	-cac---------ac-a-cc-ag-ta-ccc-tg-t-gccgctgtccacaggctgtgtttgactgcgtggtgacctccttgaagaatgtcttcaacatact
19	-cac---------cc-a--c-ag-gg-ctg-ct-g-gtttctctccacaggcggtctttgactgtgtggtgacctccttgaagaatgtcttcaacatact
20	-cac---------acaa--c-ag-gg-ccc-ca-t-gtttc---ccccaggccgtctttgactgtgtggtcacctccttgaagaatgtcttcaacattct
22	-cacaacgacaaccg-g--c-ag-gt-cca-tt------tc-ccccgcaggctgtctttgactgcgtggtgacttccttgaagaatgtcttcaacatact
23	-cac---------ac-c--c-ccgg--ttcc--------tctgtgtacaggccgtctttgactgcgtggtgacctcgctgaagaacgtattcaacatact
24	-cac---------ac-ac-c-ag-gg-ctc-tc-tt-cttctgttctcaggctgtctttgactgtgtggtcacctccttgaaaaacgtcttcaacatact
25	-cac---------cg----c-ag-gg-ctc-tt-g--attctgtccgcaggctgtcttcgactgtgtggtgacctccttgaaaaacgtcttcaacatact
26	-tac---------a--------g-gg-ctc-tggg--cttctctttgcaggctgtctttgactgtgtggtaacctccttaaagaatgtcttcaacatcct
27	-cac---------ag-c--ccag-gg-ctc-ctta--cttctgtccacaggctgtgttcgactgtgtggtgacctccttgaaaaacgtcttcaacatcct
28	cccc---------ac-a--c-ca-ggactc-tt-g-gcttctctccacaggctgtctttgactgtgtggtgacctccctgaagaacgtcttcaacatact
29	-cac---------at-g--t----gg-ctc----t-gctcctgtctacaggctgtttttgactgtgtggtgacctctttgaaaaatgtcttcaacatact
30	-tac---------ac----c-gg-ga-ctc-tt-t-gcttgtgtctgcaggctgtctttgactgtgtggtgacctccttgaagaacgtcttcaacatact
31	-cac---------ac-t--c-ca-gg-ctc-tc-g-gcttctgtccacaggctgtctttgactgtgtggtgacctccctgaagaatgtcttcaatatcct


y=1 OE:	ass	chr1	180811406	180811406	+	0
0	tttgatattttgtcctattcttaaaatgctattttt--tct-gtccatagcctgcaccagcatggactacttttagagttggcctattttgtggaatatt
2	at--gtgttttggcctgtactcaaaatgctattt-t--tct-gtccacagcctgcaccagcatggactacttttagagttggcctattttgtggaatatt
3	atcagtgttttgtcctgtactca-aatgctgttt-t--tct-gtccacagcctgcaccagcatggactacttttagagttggcctattttgtggaatatt
4	atcagtgttttgtcctgtactca-aatgctattt-t--tct-gtccacagcctgcaccagcatggactacttttagagttggcctattttgtggaatatt
5	atcagtgttttgtcctgtactca-aatactattt-t--tct-gtccacagcctgcaccagcatggactacttttagagttggcctattttgtggaatatt
6	atcagtgttttgtcctgtactca-aatgctgttt-t--tct-gtccacagcctgcaccagcatggactacttttagagttggcctattttgtggaatatt
7	tttattgt-ttgtactatactcaaaatgctgttt-c--tgt-gtctacagcctgcaccagcatggactactttcagagttggcctgttttgtggaatatt
8	---agtgtgctgccgggtacccagagtgctgttt-c--tct-gtt-acagcctgcaccagcatggactacttttagagtcggtctcttttgtggaatatt
9	ttggatcttttgtctcatacttagaatggttctt-t--tct-atccacagcctgcaccagcatggactacttttagagttggcctattttgtggaatatt
12	cttgctctcttgtcatttactcagatttctgt-t-t--tct-gttcacagcctgcaccagcatggactacttttagagtcggcctgttttttggaatatt
13	cttgctg--tcgtcttttactcagagttctgt-t-t--tct-gtccacagcctgcaccagcatggactacttttagagttggcctattttgtggaatatt
14	tatgatgtctt--------------------t-t-t--tct-ttccacagcctgcaccagcatggactacttttagagttggcctattctgtggaatatt
15	tttg-----ctatcttatattc------------------------acagcctgcaccagcatggacaactttcagagttggtctgttttgtggcatatt
17	tttgatttttt-ttttaaatttacacttctgttt-t--tct-gctcacagcctgcaccagcatggactacttttagagttggcctattttgtggaatatt
19	cataatattttgccctgtttccaaaatgctgttt-g--tct-gtctacagcctgcaccagcatggactacttttagagttggcctattttgtggaatatt
20	ttcagttttttgttatatgccaccaattttattt-t--tct-atctacagcctgcaccagcatggactacttttagagttggcctcttttgcggtatatt
22	tttagtattttcccttatacccaaaatgctgctt-t--tct-gtccacagcctgcaccagcatggactacttttagagttggcctattttgtggaatatt
24	ttcagtattttgccctgcactcaaaatgccgttt-ccctct-ctctacagcctgcaccagcatggactacttttagagttggcctattttgtggaatatt
26	tgcagtgttttgccctttgatcagcatgctgttt-t--tct-gtctacagcctgcaccagcatggactacttttagagttggcctattttgtggaatatt
27	gtctgtattttgccctatacccaaagtgctgttt-t--tct-gtccacagcctgcaccagcatggactacttttagagttggcctattttgtggaatatt
28	atcaatattttaccctgtacccaaaatgctgttt-t--cct-gtccacagcctgcaccagcatggactacttttagagttggcctgttctgtggaatatt
31	atcaatatttttgcctatat-ttaaatgccattt-t--tttcttccatagcctgcaccagcatggactacttttagagttggcctattttgtggaatatt


y=1 OE:	ass	chr1	181710953	181710953	+	0
0	c----aaac---------c-tggtggctcttatccatc-t-tgtccacagggaattcgccaaagagagggagagagtggagaaccgaagagctttcatga
1	c----aaac---------c-cagtgaatcttatccttc-t-tttccacagggaatttgccaaagagagagagagagtggagaaccgaagggctttcatga
2	c----aaac---------c-cagtgaatcttatccttc-t-tgtccacagggaatttgccaaagagagagagagagtggagaaccgaagggctttcatga
3	c----aaac---------c-cagtgaatcttatccttc-t-tgtccacagggaatttgccaaagagagagagagagtggagaaccgaagggctttcatga
4	c----aaac---------c-cagtgaatcttatccttc-t-tgtccacagggaatttgccaaagagagagagagagtggagaaccgaagggctttcatga
5	c----aaac---------c-cagtgaatcttatccttc-t-tgtccacagggaatttgccaaagagagagagagagtggagaaccgaagggctttcatga
6	c----aaac---------c-cagtgaatcttatccttc-t-tgtccacagggaatttgccaaagagagagagagagtggagaaccgaagggctttcatga
7	t----aaat---------c-cagagaacctt---cttc-t-tgtccacagggaatttgccaaagagagagagagagtggagaataggagagctttcatga
8	c----aagtcccaatgac--cagctgatcttgtccttc-c--ctccacagggagtttgccaaggagagagagagggtggagaaccgcagagccttcatga
9	t----aaac---------c-cagaaaaccttccccttc-t-tgtcctcagggaatttgccaaagagagagagagagtagagaaccggagagcattcatga
11	c----aagc---------c-cagtgactcttaactttc-t-tattcacagggaatttgccaaagagagagagagagtggaaaacaggagagcattcatga
12	c----aaat---------t-cagaggac--tgtccttg-t-tgtccacagggaatttgccaaagaaagagagagagtggagaaccgaagagcattcatga
13	a----aaat---------t-caagggac--tgtccttg-t-tgtccacagggaatttgccaaagaaagagagagagtggagaaccgaagagcgttcatga
14	c----aaac---------c-cagtgact--cgcccttc-t-tttccacagggaatttgccaaagagagagagagagtggagaatcgaagagcattcatga
15	c----aaac---------t-caccgaatcttgcccttg-tttgtccacagggaatttgccaaagagagagagagagtggagaaccgaagagcgttcatga
17	c----aaac---------c-tagtgaatttggcccttt-t-tgtccacagggaatttgccaaagagagggagagagtggagaaccgaagagcgttcatga
18	c----aagc---------c-cagtgactgttacccttc-t-cgtccacagggaatttgccaaagagagagagagggtggagaatcgaagagcattcatga
19	c----acac---------c-tagtcaaatgtatatgtt-c-tgttcacagggaatttgccaaggagcgagagagagtggagaaccgaagagccttcatga
20	------------------------------------ttct-cgtccacagggagtttgccaaagagcgagagcgagtggagaaccggagggccttcatga
21	---------------------------------cactccc-cat--gcagggaattcgccaaggagagagaaagggtggagaaccgaagggcctttatga
22	catctgaac---------ttaaatgaatctgatccatc-t-tgtccacagggaatttgccaaagagagagagagagtggagaaccgaagagctttcatga
24	c----aaac---------c-tagtgaatcttatctgct-t-tgtctgcagggaatttgccaaagagagagagagagtggagaaccggagagccttcatga
25	c----acac---------c-cagtgaatctcatccacc-t-tgtccacagggaattcgccaaagagagagagagagtggagaaccggagagctttcatga
26	t----accttcacta---c-ttctgcatctccccc-tc-t-cgtccacagggaatttgccaaagagagagagagagtggagaaccggagagcgttcatga
27	c----aaac---------c-tgatgcatcttaccctcc-t-tgtccacagggaatttgccaaagagagagagagagtggagaaccggagagctttcatga
31	g----aaat---------c-caggtttttttatct-tt-g-tgtccatagggaatttgccaaagagagagagagggtggagaaccgaagagctttcatga


y=1 OE:	dss	chr1	181721876	181721876	+	0
0	aggcatgtggtcagccatctacttcatcgtgctcaccttgtttgggaactgtatcctt-tct-aa-atggtccaac--cgtg----ctgt-------cca
1	aggcatgtggtctgccatctacttcattgtgcttaccttgtttggcaactgtatcctt-ttt-aagatgtacctcc-tcaag----ctgc-------ccg
2	aggcatgtggtctgccatctacttcattgtgctcaccttgtttggcaactgtatcctt-tct-aagatgcacctcc-tcaag----ctgc-------ccg
3	aggcatgtggtctgccatctacttcattgtgctcaccttgtttggcaactgtatcctt-ttt-aagatgcacctcc-tcaag----ctgc-------ctg
4	aggcatgtggtctgccatctacttcattgtgctcaccttgtttggcaactgtatcctt-ttt-aagatgcacttcc-tcaag----ctgc-------ctg
5	aggcatgtggtctgccatctacttcattgtgctcaccttgtttggcaactgtatcctt-ttt-aagatgcacctcc-tcaag----ctgc-------ctg
6	aggcatgtggtctgccatctacttcattgtgctcaccttgtttggcaactgtatcctt-ttt-aagatgcacctcc-tcaag----ctgc-------ctg
7	aggcatgtggtcagccatctacttcatcgtgctcaccttgtttggaaactgtatcctt-tgt-aagatgctccttct-tgtg----ctgc-------ccg
8	gggcatgtggtcagcagtctacttcattgtgctcaccttgtttggaaactgtatcctt--ggccaggtg-tcctgtg-tagg----ctg--------cca
9	aggcatgtggtcagccatctacttcattgtgctcaccttgtttggaaactgtatcctt--tt-aagaccctcttctt-caag----atag-------cca
12	aggcatgtggtctgccatctacttcattgtgctcaccttgtttggaaactgtatcctc--ct-aagttgttcttctg-tatt----ctgg-------cca
13	aggcatgtggtctgccatctacttcattgtgctcaccttgtttggaaactgtatcctt--ct-aagttgttcttctg-aatt----ctga-------cca
14	aggcatgtggtctgccatctacttcattgtgctcaccttatttggaaactgtatcctt--tt-aagatgttcttctt-tatt----ctga-------ccc
15	aggcatgtggtctgccatctacttcattgtgcttacattgttcggaaactgtatcctt--tt-aagatgtctttctt-tatt----ctgg-------cca
17	aggcatgtggtcggccatctacttcattgtgctcaccttgtttggaaactgtatcctt--tt-gagatgctcttctc-tgtg----ctga--------ca
19	tggcatgtggtcggccatctattttattgtgctcaccttgtttggcaactgtatcctt-tga-aagatactcctct-----g----ctgag------atg
20	aggcatgtggtctgcaatctacttcattgtgctcaccttgtttgggaactgtatcctt-tca--agatgttcctct-----t----tgcatcacctccta
22	gggcatgtggtcagccatctacttcattgtgctcaccttgttcggcaactgtatcctt-ct--gtattgttcctgc-----ttgtg-ttga------ctg
24	gggcatgtggtctgcgatctatttcattgtgcttaccttgtttggaaactgtatcctt-ttt-aaaatgcttctc---tatt---------------ctg
25	gggcatgtggtcagccatctatttcattgtgctcaccttgtttggaaactgtatcctt-ttt-aaagtgcttccct--t--g---------------ctg
26	aggcatgtggtcagctatctatttcattgtgctcaccttgtttggaaactgtatcctt-ttt-aagatagtcctctt-catg----ctgc-------ctg
27	aggcatgtggtcggctatctacttcattgtgctcaccttgtttggaaactgtatcctt-tta-aagaagctcctctt-tgtg----ctgc-------ctg
31	aggcatgtggtcagccatctacttcattgtgctcaccttgtttggaaactgtatccttttta-aagatgcttctgtt-tatgcttc-tgc-------ctg


y=1 OE:	dss	chr1	181772232	181772232	+	0
0	acctggcctacgtttactttgtgtccttcatcttcttctgctccttcttggtgag-aa-c-a-ctgtgct------cctg-c----cctgcggtgtgg--
1	atctggcctacgtgtactttgtctccttcatcttcttctgctccttcttggtgagcaa-c-a-ttgtgct------cttg-c----cttgcgatatgg--
2	atctggcctacgtgtactttgtctccttcatcttcttctgctccttcttggtgagtaa-c-a-ttgtgct------cttg-c----cttgccatgtgg--
3	atctggcctacgtgtactttgtctccttcatcttcttctgctccttcttggtgagcaa-c-a-ttgtgct------cttg-c----cttgctatgtgg--
4	atctggcctacgtgtactttgtctccttcatcttcttctgctccttcttggtgagcaa-c-a-ttgtgct------cttg-c----cttgctatgtgg--
5	atctggcctacgtgtactttgtctccttcatcttcttctgctccttcttggtgagcaa-c-a-ttgtgct------tttg-c----cttgctatgtgg--
6	atctggcctacgtgtactttgtctccttcatcttcttctgctccttcttggtgagcaa-c-a-ttgtgct------cttg-c----cttgctttgtgg--
7	acctggcctacgtgtacttcgtttccttcatcttcttctgctccttcttggtgagcaa-c-c-ctgtgct------cgtg-ccgcc-ttgagatgtga--
8	accttgcctacgtctacttcgtctccttcatcttcttctgctccttcctggtgagtga-t-g-caatgtttg----ct-g-c-------ga-atgtgg--
9	acctggcctatgtttacttcgtctccttcattttcttctgctccttcctggtgagcta-c-a-ttatgcc------tttg-c-----tggtgatgtgg--
12	acctggcctacgtttattttgtctccttcatcttcttctgctccttcctggtaagtaa-g-a-atttgcc------ttta-t-----tggtggtgtgc--
13	acctggcctacgtttattttgtctccttcatcttcttctgctccttcctggtgagtaa-g-a-attttcc------tttc-t-----ttgaggcatgc--
14	atctggcctacgtttactttgtctccttcatcttcttctgttccttcctggtgagcaa-c-a-ttatgcc------tttg-t-----ttgaggtgcac--
15	atctggcctacgtttactttgtctccttcatcttcttctgctccttcctggtgagcaa-c-a-ttatgcc------cctg-t-----gtgggatgtgt--
17	acctggcctacgtttactttgtctccttcatcttcttctgctccttcttggtgagcaa-cg--tcgtggtcctgttcttg-c-----ttgaggtgtag--
19	acctggcctacgtgtacttcgtctccttcatcttcttctgctccttcctggtgagcaa-t-c--c-tatg------cctggc-----c--ggctgtgg--
20	acctggcctacgtctactttgtctccttcatcttcttctgctccttcctggtgagcaa-cac--agggtg------cctagc-----tcaagacaggggt
22	acctggcctatgtctactttgtctccttcatcttcttctgctccttcctggtgagccg-c-gc-tgcacc------tttggc-----ttgggatgtgg--
24	acctggcctacgtgtacttcgtctccttcatcttcttctgctccttcctggtgagcaa-c-cg-tgagct------atcagc-----tcaagagg-gg--
25	acctggcctacgtttactttgtctccttcatcttcttctgctccttcttggtgagcca-c-ag-ggtgcc------cttggc-----ttgagaggtgg--
26	atctggcctacgtttactttgtctccttcatcttcttctgctccttcttggtgagtaaac-c--tgcact------cttggc-----tcgagatgcgg--
27	atcttgcctacgtttactttgtctctttcatcttcttctgctccttcttggtgagcaa-cat--tgtgct------cttggc-----ttggggtgtgg--
31	acctggcctacgtttactttgtctctttcatcttcttctgttccttcttggtaagcaa-g-a-ttatggc------cttgat-----ttgagatgagg--


y=1 OE:	ass	chr1	181737524	181737524	+	0
0	-ggg----ct-c---------a-cc-c-------cacc-c-----cacaggatccgcagggcctgccactacattgtgaacctgcgctactttgagatgt
4	-atg----c--c---------c-ac-t-------g--c-c-----cgcaggatccggagggcctgccactacatcgtgaacctgcgctactttgagatgt
5	-atg----c--c---------c-ac-t-------g--c-c-----cgcaggatccggagggcctgccactacatcgtgaacctgcgctactttgagatgt
6	-ttg----c--c---------c-ac-t-------g--c-c-----cgcaggatccggagggcctgccactacatcgtgaacctgcgctactttgagatgt
7	-agg----ct-c---------t-cc-t-------g--cctccacacacaggattcggagggcctgccactacatcgtgaacctgcgctactttgagatgt
8	-ggg----cc-a----------------------a--ccc-----cacaggatccggagagcctgccactacattgtgaacctgcgctactttgagatgt
9	-tgg----ct-ccacc-----c-cc-caccccacc--ccc-----cacaggatccggagggcctgccactacatcgtgaatctgcgctactttgagatgt
10	-ggg----ct-ccc-------c-tc-c-------c--atg-----cacaggatccggagggcctgccactacattgtaaacctgcgctactttgagatgt
11	-ggg----ct-ccgct-----c-tc-c-------c--gtg-----cacaggatccggagggcctgccactacatcgtaaacctgcgctactttgagatgt
12	-gggtgagct-caacaggcttt-tc-t-------c--atc-----cacaggatccgcaaggcttgccactacattgtgaatctacgctactttgagatgt
13	-gggtgagct-caagaggcttt-tc-t-------c--atc-----cacaggatccgcagggcctgccactacattgtgaacctacgctactttgaaatgt
14	-gg-----ctc----------t-cc-c-------a--ccc-----cacaggatccgcagggcctgccactacattgtgaacctgcgctacttcgagatgt
15	--------ct-c---------c-cc-c-------a--ccccctc-cgcaggatccgcagggcctgccattacattgtgaacctgcgctacttcgagatgt
17	-ggt----ct-catctg----cc----------------c-----cacaggatccggagggcctgccattacattgtgaacctgcgctactttgagatgt
18	-aag----ct-caaca-----cc----------------c-----cacagcatccggagggcctgccactacattgtgaacctacgctactttgagatgt
19	-g-g----ct-cc--------t-c---------------c-----cccaggatccgcagggcctgccactacattgtcaatctgcgctactttgagatgt
20	-a-g----tc-tg--------c-ct-c-------t--gcc-----cgcagcatccgcagggcctgccactacatcgtcaacctgcgctacttcgagatgt
22	-a-a----cc-a-----------tt-t-------c--ccc-----cgcaggatccgcagggcctgccactacattgtcaacctgcgctacttcgagatgt
24	-a-g----ct-cg--------t-tcgc-------t--gcc-----cacaggatccgcagggcctgccactacatcgtgaacctgcgctacttcgagatgt
25	-g-g----ct-g-----------ctgc-------a--ccc-----cacaggatccgcagggcctgccactacatcgtgaacctgcgctactttgaaatgt
26	-g-g----ct-ct--------g-cca-----------ctgcc---cccaggatccgcagggcctgccactacatcgtgagtctgcgctactttgagatgt
27	-g-g----ct-ca--------t-cca-----------ccc-----ttcaggattcgcagggcctgccactacatcgtgaacctgcgctactttgagatgt
28	-gag----cc-c---------c-cc-c-------a--acc-----cacaggatccggagggcctgccactacatcgtgaacctgcgctactttgagatgt
29	-gggt------c---------c-gc-c----------ttc-----cacaggatccggagggcctgccactacatcgtgaacctgcgctactttgagatgt
30	ggg-----ct-c---------c-cg-c-------c--tca-----cacaggatccggagagcctgccactacatcgtcaacctgcgctactttgagatgt
31	-gg-----cg-c---------a-cc-c-------c--tcc-----cgcaggatccggagggcctgccactacatcgtgaacctgcgctacttcgagatgt


y=1 OE:	dss	chr1	180938712	180938712	+	0
0	ctgcagagcacagagtcag------gatctagagggtctgcgccacccaggtgagt-gacag----gagct-gagccct-ga-catgg-ga--g----g-
1	ctgcagaggacagggtcgg------gatctggaggacatgtgctgtcaaggtgagt-gacag----gagaaagagc-ca-ga-ctgca-ga-ag----ga
2	ctgcagaggacagggccag------gacctggaggacatgtgctgtcaaggtgagt-gacaa----gagaaagagc-ca-ga-ctgca-ga-cg----ga
3	ctgcagaggacagggtcag------gatctggaggacatgtgctgtcaaggtgagt-gacag----gagaaagagc-ca-ga-ttgca-ga-ag----ga
4	ctgcagaggacagggtcag------gatctggaggacatgtgctgtcaaggtgagt-gacag----gagaaagagc-ca-ga-ttgca-ga-ag----ga
5	ctgcagaggacagggtcag------gatctggaggacatgtgctgtcaaggtgagt-gacag----gagaaagagc-ca-ga-ttgca-ga-ag----ga
6	ctgcagaggacagggtcag------gatctggaggacatgtgctgtcagggtgagt-gatgg----gagaaagagc-ca-ga-ttgca-ga-ag----ga
7	tctcagaggacagaggcga------gctctggaggacacaccccatcccagtaagt-gacag----ga--aggaggcct-ga-ctgca-gg--------g
10	ctgccgaggacagagccca------gttctggggggcgtgtgctgtccgggtgagt-gacag----gagcgcgggtcccccc--tgca-ag-gg-----g
11	ctacagaggacagagtccagttccagttctagggggcacacaccaggcgggtgagt-ggcag----gagcgagagtgctcac--taca-gaa--------
12	ccacagaggatggactgta------gctctggaggccacatgcccagtgggtgagt-ggcag----gagcaa--gccctgat--taca-ta-gg-----g
13	tcacagaggacaggatcca------gctctgggggccatgtgcccactgggtgagt-ggcag----gagcaa--gccctgac--gaca-ta-ag-----g
14	ctacagaggatagagtcca------gctctggaggccacatgcccactgggtgagt-ggcaa----gaccaa--tccct-g-------------------
15	ctgcagagggcagagtcca------gttctggaggacacatgccacccaggtgagt-gccag----aagcaagaaccct-gac-tgca------------
16	ctgcagaggttggagccta------gctctggaggacatgtgccacctgggtaagt-gacag----aag----agccca-aac-cacag-t-gga----c
17	ctgcagaggacagagtcca------gttctggagggcacatgccacctgggtaagt-ggcag----gagtaggagccct-gat-tgca-gg-aga----g
18	ctgcagagaacagggtcca------gctccagtgggcacgggccacccaggtgagt-ggcgg-----------aggcct-ggc-cgcc-ag-a------g
19	ctgtgcagggcagagttca------gttcccggggtcctgagtcatcccggtaggt-gacag----gaacaaga------------ca-gg-aggtgg-g
20	ctgcagaagacacagtcat------gttccagacaacctgtgtcatctcagtaagt-gacagtaaagagcaaga------------ca-gg-aggtga-g
22	ctgccggacaccgactcgc------attccagagggcctgtgacatctccgtgagt-gacag----gagcaagt------------ca-gg-aggtgg-g
26	ctgcagaggccagagatga------gtcctggagggcaggtgccatcccggtgagt-gacgg----gagcaagggcctt-gac-tgtg-gg-acgtgg-g
27	ctgcagaggacagagttga------attctggagggcatgcgtcatcccggtaagt-gacag----gagcaagaaccct-gac-cgca-gg-actgg--g
28	ctgcagaggacagagctga------gttctggagggtgcatgccatcccggtgagt-gacag----gagcaagagcact-gc--c-ca-gg-ggaggg-g
31	gccaggaggacagagctga------gatctggagggcgcatgcctttggggtgagtt--------------------tt-gg--c-ca-tg-gagctg-g


y=1 OE:	dss	chr1	181795045	181795045	+	0
0	ttaccactcctccctgcggctgtcagcccatcgcctgaactctgactcaggtgag--caggt---c--ttctg--------tg-tccca-c--cct--tc
1	ttaccactcctccttgcggctgtcagcccaccgcctgaactctgattcaggtga-----ggt---c--ttcag--------tg-tccag-c--tct--tg
2	ttaccactcctccttgcggctgtcagcccaccgcctgaactctgattcaagtaag--gaggt---c--ttcag--------tg-tccag-c--tct--tt
3	ttaccactcctccttgcggctgtcagcccaccgcctgaactctgattcaggtgag--gaggt---c--ttcag--------tg-tccag-c--tct--tt
4	ttaccactcctccttgcggctgtcagcccaccgcctgaactctgattcaggtgag--gaggt---c--ttcag--------tg-tccag-c--tct--tt
5	ttaccactcctccttgcggctgtcagcccaccgcctgaactctgattcaggtgag--gaggt---c--ttcag--------tg-tccag-c--tct--tt
6	ttaccactcctccttgcggctgtcagcccaccgcctaaacgctgattcaggtgag--gaggt---c--ttcag--------tg-tccag-c--tct--tt
7	ttaccactcctccctgcggctgtcagcccatcgcctgaactctgactcaggtgag--a--------------------------tcttc-c--tg---t-
8	ctaccactcatccctgcggctgtctgcccaccgcctcaactcagactcaggtgtg--gaggc---c--gcaag--------c--actac-----------
9	ttaccactcctccctgaggctgtcagcccaccgcctgaactccgattcaggtgaa--ggggg---c--ttcag--------ggatctgt-ctgtcc--t-
10	ttaccactcttccctgcggctgtcagcccaccgcctgaactcggactcaggtgag--ctcat---g---tcag--------gg-tctcc-c--tc---c-
11	ttaccactcttccctgcggctgtcagcccaccggctgaactcagactcaggtgag--gtggt---c--gggag--------gg-tctac-c--tca--t-
12	ttaccattcctccctgaggctgtcagcccaccgcctgaattctgactctggtgag--agggtcatt--tttgg--------ca-tttat-c--tct--t-
13	ttaccattcctccctgaggctgtcagcacaccgcctgaattctgactctggtgag--agagtcatt--tttag--------ca-tgtgt-c--tgt--t-
14	ttaccactcctccctgcggctgtcagcacaccgcctgaattctgactctggtgag--agagt---c--ttcag--------ca-tctgc-c--tct--t-
15	ctaccactcctccctgcggctgtcagcccaccgcctgaactccgactctggtgag--aggat---c--tccag--------cg-gccgc-c--tgt--c-
17	ttaccactcctccctgcggttgtcagcccaccgcctgaactccgactcaggtgag--ggggt---c--ttcag--------ca-tggcccc--tct--c-
18	ttaccactcctccctgcggctgtcggcccatcgcctgaacgcagactccggtgag--g-ggt---c--ttcag--------tg-tctgctc--ttt--g-
19	ttaccactcctccctgcggctgtctgcccatcgcctcaactctgactcaggtgag---g------c--ctcca--------ct-cttgc-c--t------
20	ctaccactcttccctgcggctatcggcccaccgcctggactcggactcaggtgag---g------cgccctca--------ct-cttca-----------
22	ttaccactcctccctacgactgtcagcccatcgcctgaactcagattcaggtgag---a------g--ga--------------ttttc-c--t------
24	ttaccactcctccctgaggctgtcagcccaccgtctgaactcggactcaggtgagaagg------t--cttca--------ct---ctg-c--g------
25	ttaccactcctccctgaggctgtcggcccaccgcctgaactctgactcaggtgagc-ag------g--ctgcagagcgggcct-ctctg-t--g------
26	ttaccactcctcgctgaggctgtcagctcatcgcctgaattctgactcaggtgaggggg------a--cttcc--------ct-gttca-cc-t------
27	ttaccactcctccctcaggctgtcagcccatcgcctgaactctgactcaggtgaggaag------c--cttcg--------ct-gtctg-cc-t------
29	ttaccactcctccctgcggctgtcagcccaccgcctcaattctgactcaggtgag--gt------c--tttga--------tg-ttgac-c--tctttc-
31	ttaccattcctccctgcggctgtctgcccatcgcctgaactccgactcaggtgag--ga------c--ttcgc--------cg-ttttc-c--tctccc-


y=1 OE:	dss	chr1	180787855	180787855	+	0
0	tttccaaacctgtgaaaaggaacttgccaaaatcaacacattttattcaggtgagt-aa---tcgc-------aagagacaag-----------tttctg
2	tttccaaacctgtgaaaaagaacttgccaaaatcaacacattttattcaggtgagt-aa---t---------taagagacttttttttttttt-tttttg
3	tttccaaacctgtgaaaaagaacttgccaaaatcaacacattttattcaggtgagt-aa---t---------taagagacttttt---------tttttg
4	tttccaaacctgtgaaaaagaacttgccaaaatcaacacattttattcaggtgagt-aa---t---------taagagacttttt---------tttttg
5	tttccaaacctgtgaaaaagaacttgccaaaatcaacacattttattcaggtgagt-aa---t---------taagagacttttt---------tttttg
6	tttccaaacctgtgaaaaagaacttgccaaaatcaacacattttattcaggtgagt-aa---t---------taagagactttttttttttttttttttg
7	tttccaaacctgtgaaaaagaacttgccaaaattaacacattttattcaggtgagt-ac---tcac-------aagagata-a-----------ttttca
8	tttccaaacctgtgaaaaggaacttgccaaaatcaacaccttttactcaggtaagc-ag---tcac-------tagagacc-a-----------tctcc-
9	tttccaaacctgtgaaaaagaacttgccaaaatcaacacgttttattcaggtgagttat---ttat-------aagagaca-a-----------tttctc
12	tttccaaacctgtgaaaaggaacttgccaaaatcaacacattttattcaggtgagt-ag---tcac-------ac-------------------------
13	tttccaaacctgtgaaaaggaacttgccaaaatcaacacattttattcaggtgagt-ag---tcac-------ca-------------------------
14	tttccaaacctgtgaaaaggaacttgccaaaatcaacacattttattcaggtatgt-ag---tcac-------aaaagaca-a-----------tttctg
15	tttccaaacctgtgaaaaagaacttgccaaaatcaacacattttattcaggtgagt-ag---tcac-------aaaagact-a-----------tttctg
17	tttccaaacctgtgaaaaagaacttgccaaaatcaacacattttattcaggtgagt-ag---ttac-------aaaagata-a-----------tttctg
19	tttccaaacctgtgaaaaggaacttgccaaaatcaacacattttattcaggtgagt-ta---ttttggggct----agata-t-----------gttttg
20	tttccaaacctgtgaaaaggaacttgccaaaatcaatacattttattcaggtgagt-gg---tttttttttt----acata-------------attttg
22	tttccaaacctgtgaaaaggaacttgccaaaatcaacacattttattcaggtgagt-aatttttttggtaga--------c-a-----------attt-g
24	tttccaaacctgtgaaaaagaacttgccaaaatcaacacattttattcaggtaagc-ag---ttttttggta----agaca-a-----------tttctg
26	tttccaaacctgtgaaaaggaacttgccaaaatcaacacattttattcaggtgagt-ag---ttttttggta----gaaca-a-----------tttctg
27	tttccaaacctgtgaaaaagaacttgccaaaatcaacacattttattcaggtgagt-ag---gattttggta----agaca-a-----------tttctg
31	tttccaaacctgtgaaaaggaacttgccaaaatcaacacattttattcaggtgagt-gt---tttttggttt-aagagaga-g-----------gt----


y=1 OE:	dss	chr1	181736435	181736435	+	0
0	aaagccatggtgccccacagctctatgttcatcttcagcaccaccaacccgtaagacac--c-c-----tggcact----g------c-cctcccca---
2	aaagccatggtgccccacagctcaatgttcatcttcagcaccaccaacccgtaagccac--c-c-----tcgagtt----g------c-tc---cct---
3	aaagccatggtgccccacagctcaatgttcatcttcagcaccaccaacccgtaagccac--c-c-----tcgcatt----g------c-tc---cct---
4	aaagccatggtgccccacagctcaatgttcatcttcagcaccaccaacccgtaagccac--c-c-----tcgcgtt----g------c-tc---cct---
5	aaagccatggtgccccacagctcaatgttcatcttcagcaccaccaacccgtaagccac--c-c-----tcgcgtt----g------c-tc---cct---
6	aaagccatggtgccccacagctcaatgttcatcttcagcaccaccaacccgtaagccac--c-c-----tcgcgtt----g------c-tc---cct---
7	aaagccatggtgccccatagctccatgttcatcttcagcaccaccaacccgtaagatac--c-c-----taccatt----g------c-tc---cta---
8	aaagccatggtgccccacagttccatgttcatcttcagcaccagcaacccgtgagaaac--c-a-----gac-agc----a-------------------
9	aaagccatggtgccccacagctccatgttcatcttcagcaccaccaacccgtaagatgt--t-t-----tcctgct----g------c-tc---ctc---
10	aaagccatggtgccccatagctccatgttcatcttcagcaccaccaacccgtaaggccc--c-c---------gcc----a------c-tc---ttc---
11	aaagccatggtgcctcacagttccatgttcatcttcagcaccaccaacccgtaaatcgt--c-t-----t--------------------t---ctt---
12	aaagccatggtgccccatagctctatgttcatcttcagcaccactaacccgtgagccat--g-c-----tcctgtt----g------c-at---ccca--
13	aaagccatggtgccccatagctctatgttcatcttcagcaccactaacccgtgagctat--g-c-----tcctgtt----g------c-at---ccca--
14	aaagccatggtgccccacagctctatgttcatcttcagtaccaccaacccgtaagccat--g-c-----tcctgtt----g------t-gt---ccc---
15	aaagccatggtgccccacagctccatgttcatcttcagcaccaccaacccgtaagccaa--g-c-----tcctgtt----g------c-tc---cct---
17	aaagccatggtgccccacagctccatgttcatcttcagcaccaccaacccgtgagacac--t-t-----tcc-agt----g------c-ta---ccc---
18	aaagccatggtgccacacagctccatgttcatcttcagcaccaccaacccgtaagatgc--c-t-----tct-gtc----g------c-tc---ct----
19	aaggccatggcgccccacagctccatgttcatcttcagcaccaccaacccgtaaggcac--c-g-----cc----a----t------c-ac---cca---
20	aaagccatggtgccacacagctccatgttcatcttcagcacaaccaacccgtaagtcac--t-tgctcgcc----a-----------c-ac---ccc---
22	aaagccatggtgccccacagctccatgttcatcttcagcaccaccaacccgtaag-cac--c-t-----gc----cctc-a------c-cc---tcc---
24	aaggccatggtgccccacagctcgatgttcatcttcagcaccaccaacccgtaagacac--cct-----cc----att--g------c-ca---cctccc
25	aaagccatggtgcctcacagctcaatgttcatctttagcaccaccaacccgtaagacac--cct-----cc----ttc--g------c-ca---ccccgc
26	aaagccatggtgccccacagctccatgttcatcttcagcaccaccaacccgtaaggccc--t-c-----tc----ctgtca------ctcc---ccc---
27	aaagccatggtgccccacagctctatgttcatcttcagcaccaccaacccgtaagaccc--a-c-----cc----ccatgg------c-cc---ccc---
28	aaagccatggtgccccacagctccatgttcatcttcagcaccaccaacccgtaagaca-----c-----t-ccatc----c------c-tt---ccc---
29	aaagccatggtgccccatagctccatgttcatcttcagcaccaccaacccgtgagacac--c-t-----tcccttc----c------t-gc---ccc---
30	aaagccatggtgccccacagttccatgtttatcttcagcaccaccaacccgtaagacac--c-t-----tc---tt----gccttctg-cc---ccg---
31	aaagccatggtgcctcacagctccatgttcatcttcagcaccaccaacccgtaagacatagc-c-----cc---tc----acctccca-tc---ccc---


y=1 OE:	ass	chr1	180036925	180036925	+	0
0	ttttccctt--tga---------caattg----tc-at--gccc-tccaggttctaagcgcttttctcctgctggcctccagcatcgcatgacagcagag
1	ttttccatt--tga---------ccattg----tc-at--gccc-tccaggttctaagcgcttttctcctgctggcctccatcatcgtatggcagcagaa
2	ttttccatt--tga---------ccattg----tc-at--gcct-tccaggttctaagcgcttttctcctgctggcctccatcatcgtatggcagcagaa
3	ttttccatt--tgt---------ccattg----tc-at--gcct-tccaggttctaagcgcttttctcctgctggcctccatcatcgtatggcagcagaa
4	ttttccatt--tga---------ccattg----tc-at--gcct-tccaggttctaagcgcttttctcctgctggcctccatcatcgtatggcagcagaa
5	ttttccatt--tga---------ccattg----tc-at--gcct-tccaggttctaagcgcttttctcctgctggcctccatcatcgtatggcagcagaa
6	tttcccatt--tga---------ctattg----tc-at--gcct-tccaggttctaagcgcttttctcctgctggcctccatcatcgtatggcagcagaa
7	c-ttctatc--tga-------------tg----tt-ct--gcac-tccaggttctaagcgcttttctcctgccggcctccagcaccgtatggcagcagaa
8	gtctccggg--tga---------cagttg----ct-gt--gtccttccaggtgctaagcgcttttcccctgccggcctccagcaccggatgactgcagag
9	tt-tccatt--tga---------tgattg----tt-ct--gacc-tccaggttctaagcgcttttctcctgctggcctccaacatcgtatggcagcagaa
10	ttttcgatt--tga---------caattg----tt-gt--gcac-accaggttctaagcgattttctcctgctggcctccaacatcgtatggcagtagaa
11	tttgccatc--tga---------ctatta----tt-at--atac-ac-aggttctaagcgattttctcctgctggcctccaacatcgaatggcagtagaa
12	cttttgatt--tag---------cgatac----cc-ct--gtccc-ccaggtcccaagcgtttctctcctgctggccttcagcatcgcatggctgcagag
13	cttttgatt--taa---------cgatgc----at-ct--gtgc--ccaggtcctcagcgtttctctcctgctggccttcagcatcgcatggctgcagaa
15	ttttcaatt--tga---------cagttg----ttaacc-accc-tacaggttctaagcgcttttctcctgctggcctccagcaacggatgacagcagag
16	ttttccatt--tga---------caatc------t-at--acct-tctaggttctaagcgcttttctcctgctggcctccagcatcgtatggcagcagaa
17	ttttcc------------------aattt----tt-at--accc-tctaggttcgaaacgcttttctcctgctggcctccagcatcgtatgacagcagaa
19	-------------a---------taattg----tt--t--gtcc-tccaggttctaagcgcttctcccctgctggtctccagcatcgtttggcagcagag
20	-----cacttt--c---------acacaattttta--t--gatt-tccaggtactaagcgattttctcctgctggtctccagcatcgaatgacagcagaa
22	-----gaac--ttttcacagttgtacttg----ttg-t--gcct-tctaggttccaaacgcttttctcctgctggccttcagcatcgaatggccgccgaa
23	ctctacatt--tgg---------caattg----tta-t--gccc-tccaggttctcagcgcttctcccctgctggcctccagcatcgaatggcagctgaa
24	ttttatata--tga---------caatta----ta--t--gtct-tccaggttctaagcgcttttctcctgctggcctccagcatcggatggcagcagaa
25	tttcatatt--tga---------caattg----ta--t--gcct-tccaggttccaagcgtttttcccctgctggcctccagcatcgtatggcagcagaa
26	tcttacatt--tga---------cagtca----ct--tatgcct-tccaggttctaagcgcttttctcctgctggcctccagcaccgtatggcggcagaa
27	ttttacatt--tga---------cacttc----t---tatgccc-tccaggttctaagcgcttttctcctgctggcctccagcatcgtatggtagcagaa
28	ttttccttt--tga---------cggttg----tt-tt--gcct-tttaggttctaagcgcttttctcctgctggcctccaccaccgtatggcagcagaa
29	tttcccgtg--tga---------cacttg----cg-gt--gccc-tccaggttctcggcgcttctcccctgctggcctgcagcaccgcttggcagcagaa
30	tgtttcatt--tgg---------cggttg----tc-gc--tccc-tccagggtcgaagcgcttctcccccgctgtccttcagcaccgcctggccgccgag
31	--tttacct--tga---------cagtta----tt-at--gccc-tccaggttcaaagcgcttttcccctgctggcctccatcaccggttagcagcagaa


y=1 OE:	dss	chr1	180936671	180936671	+	0
0	ggccccctacagccaggagctggggctgccccaggagaacagcagagatggtgagagactgc-ggttg-gttc-atgctcagcataggcct---------
2	gggcccctgcagccaggaactggagccgcccctggagaacagcagagacggtaaggggctgc-cgctg-gttc-ctgcccagcccaggcctggtgt-gg-
3	cggcccctgcagccgggaaccggagccgcccctggagaacagcagagatggtaaggggctcc-cgctg-gttc-ctgcccagcccaggactggtgt-gg-
4	gggcccctgcagccgggaaccggagccgcccctggagaacagcagagatggtaaggggctgc-cgctg-gttc-ctgcccagcccaggcctggtgt-gg-
5	gggcccctgcagccgggaaccggagccgcccctggagaacagcagagatggtaaggggctgc-cgctg-gttc-ctgcccagcccaggcctggtgt-gg-
6	gggcctctgcagccgggaaccggagctgcccctggagaacagcagagatggtaaggggctgc-cgctg-gttc-ctgcccagcccaggcctggtgt-gg-
11	ggacccgcgtacccaggagcagaatccacccgtcaaaagccgtggagctggtaag-gctcac-a--ta-gccc-ctgcttagccc---------------
12	ggaccaatgttatcaggagcctgggctgcctctggagagcaatggagatggtaag-gattgc-tg-t---------------------------------
13	ggaccagtgctgtcaggagcctgtgctgcctctggagagcaatggagatggtaag-gactgc-tg-t---------------------------------
14	gaacctctgttgccaggagcctgggccagccctagagagcaccggagatggtaag-gattgc-tg-ttggtcc-atgtttgtct----------------
17	gggtccctgtggccaggagctggacctgcccctggagagcagcggagacggtaag-gactgccct-t--gctc-agactcagcct---------------
18	gggcccctgtggccaggcacaggagcagccccaggagagctgcagagatggtaag-gactgcctg-tg-gcgt-gcactccgact---------------
19	tggcccctggagcccagagctggagccgccccca---------------ggtaagggactgc--------------------tgggtgggtggggg-ag-
24	gggtgcccgaagccaggaccccacagcaccgctggaggaccgcagagatggtaagggatggc--------------------ccgggggctagggt-ggt
31	ggattcctgcagccagacgccagagctgctcctggaggacagcggaggaggtaag-gattgc-ccttg-attcg------------------tgcccag-


y=0 OE:	dss	chr1	181557829	181557829	+	0
1	gctggcttagtggcactctgtggggaaaggactctggttatgttaagaaagtgagattgctgccaaaagg--------cctctgggcctgctgtgaccag
2	gctggcttagcagcactctatggggaaaggactcgggttatgttaagaaagtgagattgctgccaaaagggatcccaccctctgggcctgctgtgatcgg
3	gctggcttagcggcactctgtggggaaaggactcgggttatgttaagaaagtgagattgctgccaaaagggatcccaccctctgggcctgctgtgaccgg
4	gctggctcagcggcactctgttgggaaaggactcgggttatgttaagaaagtgagattgctgccaaaagggatcccaccctctgggcctgctgtgactgg
5	gctggctcagcggcactctgtggggaaaggactcgggttatgttaagaaagtgagattgctgccaaaagggatcccaccctctggacctgctgtgactgg
6	gctggtttagcagcaccctgtggggaaaggactcaggttatgttaagaaagtgagattgctgccaaaagggatcccaccctctgggcctgctgtgaccgg


y=0 OE:	ass	chr1	180138020	180138020	-	0
1	gaattgtgtaagttcatctgctaccctgctgcctgtgttctttataacagtggttcctgttataaagaacagttcctgcctgctgcatattttgtacata
2	caattgtgtaagtccatctgctaccctgctgcctctgttctttataacagtggttcctgttataaagaacagttcctgcctgctgcatattttatacata
3	taatt-tgtaagtccatctgctaccctgctgcctctgttctttataacagtggttcctgttataaagaacagttcctgcctgctgcatattttgtacata
4	taattgtgtaagtccatctgctaccctgctgcctctgttctttataacagtggttcctgttataaagaacagttcctgcctgctgcatattttgtacata
5	taattgtgtaagtccatctgctaccctgctgcctctgttctttataacagtggttcctgttataaagaacagttcctgcctgctgcatattttgtacata
6	caattgtgtaagtccatctgctaccctgctgcctctgttctttataacagtggttcatgttataaagaaccgttcctgcctgctgcatattttgtacata


y=0 OE:	ass	chr1	180814522	180814522	+	0
2	tag-t-t---gttttggctttaaggacatcatttaacttctctgaaacagtttcctcatctgttaaatgagcttaacaccttaaatttgcagggttgtt-
3	tag-t-t---gttttggctttaaggacatcatttaacttctctgaaacagtttcctcatctgttaaatgagcttaacaccttaaatttgcagggttgtt-
4	tag-t-t---gttttggctttaaggacatcatttaacttctctgaaacagtttcctcatctgttaaatgagcttaacaccttaaatttgcagggttgtt-
5	tag-t-t---gttttggctttaaggacatcatttaacttctctcaaacagtttcctcatctgttaaatgagcttaacaccttaaatttgcagggttgtt-
6	tag-t-t---gttttggctttaaggacatcatttgacttctctgaaacagtttcctcatctgttaaatgagcttaacaccttaaatttgcagggttgtt-
17	tagt--t---gttttggctttaaggacattccttaactttttaaaaacagttttctcatctgttaaatgaacttaatatattaaatttacagggttgttt
28	tta-ttagttgttttggttttatggatattacttaacttctctgaaacagtttcttcatctgttaaatgaacttaa---------ttggcagggttgttt


y=0 OE:	ass	chr1	180326274	180326274	+	0
2	ccctaaaaccataaaacta----gtccttccttcccttttccacaggcagaggagcctctc------ccagttgccaccaccaccaccatcagcccatgg
3	ccctaaaaccgtaagacaagtcagtcctttcctcccttttccacaggcagaggagcctctc------ccagttgccaccaccaccgc---cagcccatgg
4	ccctaaaaccataagacaagtcagtccttccctcccttttccacaggcagaggagcctctcccactcccagttgccaccaccaccac---cagcccatgg
5	ccctaaaaccataagacaagtcagtccttccctcccttttccacaggcagaggagcctctcccactcccagttgccaccaccaccac---cagcccatgg


y=0 OE:	ass	chr1	180634822	180634822	-	0
3	acat---attatatataattaaata-------taa---------ttatagatgtaaaacaaaattttcagattc----t-aattctctgcttatttcaag
4	acat---attatatataattaaata-------taa---------ttatagatgtaaaacaaaattttcagattc----t-aattctctgcttatttcaag
5	acat---attatatataattaaata-------taa---------ttacagatgtaaaacaaaattttcagattc----t-aattctctgcttatttcaag
6	acat---attatatataattaaata-------taa---------ttatagatgtaaaacaaaattttcagattc----t-aattctctgcttatttcaaa
7	atat-gtattgcatataattaaatattacatgtaa---------ttatagacataaaacaaacattttaccttctatct-aatgctctgcttatttcaag
9	acataatattacatataattaaatattgcattcaa---------ttatagatataaa-caaaat-ttcagcctctctcttaaagctctgcataattcgag
14	ccataatactacatgtaattaaatattacatcaaa---------ttatagatgtaag-caaaatgttcagcttctagct-aaagctctgcctaattcaac
17	ataaaatgttgtatata------------------tacataaaattatagttgtgaa-caaaattttcagcttctatct-aaagctctgcttaattcaag


y=0 OE:	dss	chr1	180785913	180785913	-	0
0	---tt-tttt-ttata--aagaggaccttgagttaa-ggaagctc-catggtaacaga---tactg--------------------------------tg
1	tttttttttt-tttta--aagctgagtttgagttaa-ggaaactc-catggtaacaga---tgcagctc---ttacaata--------g---------ca
2	tc-ct-tttt-tttaaaaaagctgagtttgagttaa-ggaagctc-catggtaacaga---tgcagctc---ttacaata--------g---------ca
4	tt-tt---tt-tttta--aagctgagtttgcgttaa-ggaagctc-tatggtaacaga---tgcagctc---ttataataacta----a---------ca
5	tt-tt-tttt-tttta--aagctgagtttgcgttaa-ggaagctc-tatggtaacaga---tgcagctc---ttataataacta----a---------ca
6	tt-tt-ttttttttta--aagctgagtttgacttaa-ggaagctc-tatggtaacaga---tgcagctc---ttacaata--------g---------ca
7	---------c-tttta--aagcttaccttgagttaa-gaaaactc-catggtaacaga---tgttgttc---tgatcata--------a---------ca
12	---------a-ag--g--aagctgaccctgagttaa-ggaaattc-catggtgacaga---tgctatgc---ttggaata----gctag---------ca
13	---------a-ag--g--aagctggccctgagttaa-ggaaattc-catggtaacaga---ttctgtgc---ttagaata--------g---------ca
14	---------a-ag--g--aagctgacctcgagttaa-ggaaactc-catggtaacaga---tactgcac---ttagaata--------g---------ag
15	---------a-ag--g--aagctgaccttgagttaa-ggaagctc-catggtaacaga---agctacac---ttataaca--------g---------ta
17	---------a-aa--a--cagctgaccttgagttaa-ggaagctc-catggtaacaga---tgtggcacatattataaca--------g---------ca
19	---------t-t---t--aagttgaccttgagttaa-agatgctc-catggtaacaag---tgcagctg---ctgtaatg--------g---------ca
24	---------g-a---a--aaactgaccttgagttaaaagatgct-ccatggtaac---atatgctactc---tttttttt---------tttataatacc
27	---------t-t---t--aagctgaccttgagttaa-agatgcc-tcatggtaacaga---tgctgctc---ttataata--------g---------aa


y=0 OE:	ass	chr1	181094922	181094922	+	0
0	tccaaacacagtttttcccaatgcctgccactcat-c-c-cttcccgcagtgggaatgagggttcagaaataaattccctctctagcaattgctctctcc
1	ttcaaatacagtttttcccaatgcctgctaccactgctccc-tcccccagtaggaatgggggttttaaaataaaatctctctctagcaattgctctctcc
2	ttcaaacacagtttttcccaatgcctgctaccactgctccc-tcccccagtgggaatgggggttttaaaataaaatctctctctagcaattgctgtctcc
3	ttcaaacacagtttttcccaatgcctgctaccactgctccc-tcccccagtgggaatgggggttttaaaataaaatctctctctagcaattgctgtctcc
4	ttcaaa--cagtttttcccaatgcctgctaccactgctccc-tcccccagtgggaatgggggttttaaaataaaatctctctctagcaattgctgtctcc
5	ttcaaacacagtttttcccaatgcctgctaccactgctccc-tcccgcagtgggaatgggggttttaaaataaaatctctctctagcaattgctgtctcc
6	ttcaaacacagtttttcccaatgcctgctaccactgctccc-tcccccagtgggaatgggggttttaaaataaaatctctctctagcaattgctgtctcc


y=0 OE:	ass	chr1	180635587	180635587	-	0
3	-gtagataatctttaa-attcccttttagctctaaaatcctgtaatttagaaaccttgttatttta-----ttacaaaac-aaaggatacactggaaaaa
4	-gtagataatctttaa-attcccttttagctctaaaatcctgtaatttagaaactttgttatttta-----ttacaaaac-aaaggatacactgaaaaaa
5	-gtagataatctttaa-attcccttttagctctaaaatcctgtaatttagaaaccttgttatttta-----ttacaaaac-aaaggatacactgaaaaaa
6	-gtagataatctttaa-attcccttttagctctaaaatcctgtaatttagaaaccttgttatttta-----ttacaaaac-aaaggatacactgaaaaaa
14	-----gtaatcttttaaaatccctttcaat-------tcctgtaatttagagactttgctgttttagaatcttacatttctatagtatacactgaaaaaa
26	agtaaatagtgtttaa-attccctt-------taaaatcctgaaatttagatacctcattattttggtatcttacaaaactacagtatacactg------


y=0 OE:	dss	chr1	180951053	180951053	-	0
0	acatttcacattccgatttggggttgggaacagatatgtggtcaatggcggtaaggctgttactctaggacact-tgcccatccctggat-aaagggcag
1	ac-------attccaattttg-gtttggc----atatatggtcaatggctgtaaggctggtactccaggacactttgcccattgctggag-aaagggcaa
3	ac-------gttctgattttg-gtttggc----atatatggtcaatggctgtaaggctggtactccgggacactttgcccatttctggat-aaagggcaa
4	ac-------gttctgattttg-gtttggc----atatatggtcaatggctgtaaggctggtactctgggacactttgcccatttctggat-aaagggcaa
5	ac-------gttctgattttg-gtttggc----atatatggtcaatggctgtaaggctggtattccgggacactttgcccatttctggat-aaagggcaa
6	ac-------gttccgattttg-gtttggc----atatatggtcaatggctgtaaggctggtactccaggacactttgcccatttctggat-aaagggcaa
24	a-------tg---------ttggtttggg----atatatggtccatggctgtaaggctgtgactcccggacacttggtccatttttggaa-aaagagcaa
25	at-------gtgccaatttttggtttgga----cgctatggtcaatggctgtaaggctgttactccaagatgctctgcccatttctggaaaaaagagcaa
27	at-------gttccagtttggggtttgga----agctacggtcaatggctgtaagactgttactccaggacactttgcccatttctggaa-aaagagcaa


y=0 OE:	ass	chr1	180327718	180327718	+	0
1	a---aaccctttaaaagaatgttcccggtgttcccatgtatttcctatagtgtggagtgcaatgtcagacatgacaatacaatgaagttctaaacaatga
2	a---aaccctttaaaagaa---------tgttcccatgtatttcctatagtgtggagtgcaatgtcagacatgataatacaatgaaggtctaaacaatga
3	a---aaccctttagaagaa---------tgttcccatttatttcctacagtgtggagtgcaatgtcagacatgataatacaatgaaggtctaaacaatga
4	a---aaccctttagaagaa---------tgttcccatttatttcctacagtgtggagtgcaatgtcagacatgataatacaatgaaggtctaaacaatga
5	a---aaccctttagaagaa---------tgttcccatttatttcctacagtgtggagtgcaatgacagacatgataatacaatgaaggtctaaacaatga
6	a---aaccctttaaaagaa---------tgttcccatatatttcctacagtgtggagtgcaatgtcagacatgataatacaatgaaggtctaaacaatga
27	ctaaa----------aata---------agttcccacacacttcctacagtgtggagtatcatgccagatgtaatcatccaatgaggtcctagacaatg-


y=0 OE:	ass	chr1	180511294	180511294	+	0
2	ctgggttctctgttctgttttattggtctgtgtgcctacttttataccagtaccatgctgttttggtaactgcagctttatagcatgatttgaagctggg
3	ctgggttctctgttctgttttattggtctgtgtgcctacttttataccagtaccatgctgttttggtaactgcagttttatagcataatttgaagctcga
4	ctgggttctctgttctgttttattggtctgtgtgcctacttttataccagtaccatgctgttttggtaactgcagttttatagcataatttgaagctcga
5	ctgggttctctgttctgttttattggtctgtgtgcctacttttataccagtaccatgctgttttggtaactgcagttttatagcataatttgaagctcga
6	ctgggttctctgttctgttttattggtctgtgtgcctacttttataccagtaccatgctgttttggtaactgcagctttatagcataatttgaagctcgg


y=0 OE:	ass	chr1	181090232	181090232	-	0
1	atggggaactccccggcccaaaccttttagccgcttccttctccacgcagccggcagaggaaagtccctgtctgcccccaatctcttaagccctggggaa
3	atggggaactccccggcccaaaccttttagccgcttccttctccacgcagccggcagaggaaagtccctgtctgcccccaatctcttaaaccctggggaa
5	atggggaactccccggcccaaaccttttagccgcttccttctccacgcagccggcagaggaaagtccctgtctgcccccaatctcttaaaccctggggaa
6	atggggaactccccggccca-accttttagccgcttccttctccacgcagccggcagaggaaagtccctgtctgcccccaatctcttaagccctggggaa


y=0 OE:	ass	chr1	181680153	181680153	+	0
1	aaaaaaaaaaaaaa------aaaaaaaaaaagagtccccaatctcagcagctagacagagagcaagagtcaagacccaggagaaaccagtgggtggaagg
2	aaaaaaaaaaa---------aaaaa---agaaagtccccaatctcagcagctagacagagagcaagagtcaagacccaggagaaaccagtgggttgaagg
3	aaaaaaaaaaa---a---aaaaaaaaaaaaagagtccccagtctcagcagctag----agagcaagagtcaagacccaggagaaaccagtgggtggaagg
4	aaaaaaaaaaa--------aaaaaaaaaaaagagtccccaatctcagcagctagaca----gcaagagtcaagacccaggagaaaccagtgggtggaagg
5	aaaaaaaaaaa---aaaaaaaaaaaaaaaaagagtccccaatctcagcagctagacagagagcaagagtcaagacccaggagaaaccagtgggtggaagg
6	aaaaaaaaaaa---------aaaaaaaaaaagagtccccaatctcagcagctagacagagagcaagtgtcaagaaccaggagaaaccagtgggtagaagg


y=0 OE:	ass	chr1	181828376	181828376	-	0
1	ctaaggttgtaatactttaattttaatttataccagtttaactttaatagcatatgaaaacttctcttctttaacaactctgttctca-cccctcagttg
3	ctaaggttgtaatactttaattttaatttatactggtttaacttcaatagcatatgaaaacttttcttttttaacagctctgttctcacccc--cagttg
4	ctaaggttgtaatactttaattttaatttataccggtttaacttcaatagcatatgaaaacttttcttttttaacagctctgttctcaccccctcagttg
5	ctaaggttgtaatactttaattttaatttataccggtttaacttcaatagcatatgaaaacttttcttttttaacagctctgttctcaccccctcagttg
6	ctaaggttgtaatactttgattttaatttataccagtttaatttcaatagcatatgaaaacttttcttttttaacagctctgttctcaccccctcagttg


y=0 OE:	dss	chr1	181369880	181369880	+	0
1	acatcttcaggtttgttatatgggcacattgtgtgtcatgggggtttgaggtacagattattttgtcatccaagtaaataagcacagaaccagagaggta
2	tcatgttcaggtttgttatataggcaaattgtgtgtcatgggggtttgaggtacagattattttgtcatccaagtaaataagcacagaaccagataggta
3	acctgttcaggtttgtcatataggcaaattgtgtgtcatgggggtttgaggtacagattattttgtcatccaagtaaataagcacagaaccaaataggta
4	acatgttcagatttgtcatataggcaaattgtgtgtcatgggggtttgaggtacagattattttgtcatccaagtaaataagcacagaaccaaataggta
5	acatgttcaggtttgtcatataggcaaattgtgtgtcatgggggtttgaggtacagattattttgtcatccaagtaaataagcacagaaccaaacaggta


y=0 OE:	ass	chr1	180698210	180698210	+	0
3	ttgattttttt--atcattatttaatggccttctttgtctcattttacagtttttgacttaaagtttgttttgtctgataacaactcctgctcacttttg
4	ttgattttttt--atcattatttaatgaccttctttgtttcattttacagtttttgacttaaagtttgttttatctgataacaactcctgctcacttttg
5	ttgattttttt--atcattatttaatgaccttctttgtctcattttacagtttttgacttaaagtttgttttatctgataacaactcctgctcacttttg
6	ttgatttttttaaatcattatttaatgaccttctttgtctcattttacagtttttgacttaaagtttgttttatctgatatcagctcctgctcacttttg


y=0 OE:	ass	chr1	181880288	181880288	-	0
2	agcctgctgtgcaaaaggcccatctcactcccatcatgtccccacaacagcaccaagtttatttctaggaagccaatgagcagggctgggaacttgcccc
3	agcctgccgtgcaaaaggcccatctcactcccaccatgtccctgcaacagcaccaagtttatttccaggcagccaatgagcagggctgagaacttgcccc
5	agcctgccatgtgaaaggcccatctcactcccaccatgtccccgcaacagtaccaagtttatttccaggcagccaatgagcagggctgagaacttgcccc


y=0 OE:	dss	chr1	181764227	181764227	-	0
3	caact---------aatttatgatatttgctagagtccaaagatatttcagtatgtttaagaaact---tttactcaaagtc--tg------ggtctcag
4	caact---------aatttatgatatttgctagagtccaaagatatttcagtatgtttaagaaact---tttactcaaagtc--tg------ggtctcag
5	caact---------aatttatgatatttgctagagtccaaagatatttcagtatgtttaagaaact---tttactcaaagtc--tg------ggtctcag
6	caact---------aatttatgatatttgctagagcccaaagatatttaagtatgtttaagaaact---tttactcaaagtc--tg------ggtctcag
11	taactaaaaaaactaatttatgatagttgctagagctccaaaatatttaagtatgtttgagaaactctatttattggaagttgctgacacagagcctcag


y=0 OE:	ass	chr1	180919360	180919360	+	0
1	ccccttccgccaggtatctcttcccccacctccctggctgctgtttccaggccctcctctggtccccagctggccctgccacagtgttgaggagcgtgac
2	ccccttctgccaggaatctcttcccccacctccctggctgctgtttccaggcccttctctggtccccagctggccctgccacagtgttgaggagcgtgac
3	ccccttctgccaggaatctcttcccctacctccctggccgctgtttccagaccctcctgtggtccccagctggccctgccacagtgttgaggagtgtgac
4	ccccttctgccaggaatctcttcccctacctccctggccgctgtttccagaccctcctctggtccccagctggccctgccacagtgttgaggagcgtgac
5	ccccttctgccaggaatctcttcccctacctccctggccgctgtttccagaccctcctctggtccccagctggccctgccacagtgttgaggagcgtgac
6	ccccttccgccaggaatctcttcccccacctacctggctgctgtttccaggccctcctctggtccccagctggccctgccacagtgttgaggagcgtgac


y=0 OE:	dss	chr1	180605012	180605012	-	0
2	agc---------ttct-ttccctccactcttttata--gagcagagataggtgatggctaggccggcaggtt-ctgcataggtggtctagcaccttgttt
3	agc---------ttct-ttcccctcactcttttata--gagcagagataggtaatggctaggctggcaggtt-ctgcataggtggtctagcaccttgttt
4	agc---------ttct-ttcccctcactcttttata--gagcagagataggtgatggctaggctggcaggtt-ctgcataggtggtctagcaccttgttt
5	agc---------ttct-ttcccctcactcttttata--gagcagagataggtgatggctaggctggcaggtt-ctgcataggtggtctagcaccttgttt
6	agc---------ttct-ttccccccactct--tata--gagcagagataggtgatggctaggctggcaggtt-ctgcataggtggtctagcaccttgttt
26	---cttcaccagctactttccctttactccttt--atagggtagaaacaggtgatggctagactggcagt-ctctacaaaggtggtccagcattttgttt


y=0 OE:	dss	chr1	181902073	181902073	+	0
1	aaaggggcccctggagaacctctggccagctggcacactgggaggatggggtgaggccttgggaagtttgtgccatttgcagtggggaggagcctggcct
2	aaaggggcccctggagaatctctggccagctggcacactgggaggatggggtgaggccttgggaagttggtgccatttgcagtgaggaggagcctggcct
3	aaaggggcccctggagaaactctggccagctggcacactgggaggatggggtgaggccttgggaagttcgtgccatttgcagtggggaggagcctggcct
4	aaaggggcccctggagaacctctggccagctggcacactgggaggatggggtgaggccttgggaaattcgtgccatttgcagtggggaggagcctggcct
5	aaaggggcccctggagaaactctggccagctggcacactgggaggatggggtgaggccttgggaagttcgtgccatttgcagtggggaggagcctggcct
6	aaaggggcccctggagaacctcgggccagctggcacactgggaggatggggtgaggccttgggaagtttgtgccatttgcagtggggaggagcctggcct


y=0 OE:	ass	chr1	180247350	180247350	+	0
3	gacaatagaatcttctttcactatttaagtgaaaagtggttaatcatcaggtggcaggtgactttcaactcagtggagccag-c--t--ggttggagctt
4	gacaatagagtcttctttcactatttaagtgaaaagtgattactcatcaggtggcaggtgactttcaactcagtggagccag-c--t--ggttggagctt
5	gacaatagagtcttctttcactatttaagtgaaaagtgattactcatcaggtggcaggtgactttcaactcagtggagccag-c--t--ggttggagctt
6	gacaatagaatcttttttcactatttaagtgaaaagtgattaatcatcaggtggcaggtgactttcaactcagtggagccag-c--t--ggttggagctt
7	gacaacagactccatttttactatttaaatggaaaatgactaattg-caggtatgaggtggctttcaacttgagggagccaagcttccagggctgagctt


y=0 OE:	ass	chr1	180446651	180446651	+	0
0	gtt-ctat-ttgtaacagtaacatttataac---------atttctcaagaatgggaaattccataaat-------------cacattttctcttaaaat
2	gttgctac-ttctaacagtaatatttataaa---------atttttcaagaaacgggaactccataaatgtatgtttttaacct--gtttctcttaaaat
3	gttgctac-ttataacagtaatatttataaa---------atttttcaagaaaggggaactccataaatgtatgtttttaacct--gtttctcttaaaat
4	attgctac-ttataacagtaatatttataaaatttttcaaatttttcaagaaaggggaactccataaatgtatgtttttaacct--gtttctcttaaaat
5	gttgctac-ttataacagtaatatttataaa---------atttttcaagaaaggggaactccataaacgtatgtttttaacct--gtttctcttaaaat
6	gttgctac-ttgtaacagtaatatttataaa---------atttttcaagaaaggggaactccataaatgtatgtttttaacct--gtttctcttaaaat
7	gttgcaatctgttaagag-tgtatttataaa---------ttttctcaagaaatgaaaactccttaaacc--tgttattaatcttaatttctcttaaaat


y=0 OE:	ass	chr1	181337345	181337345	+	0
1	gcctgccaccacacctgactaatattttgtattttttttttttttagtagagatggggtttcactgtgttagccaggatggtagaatctactcttttaac
2	acccgccaccacgcctggctaattttttgtatttt-----gttttagtagaggcaggatttcactgtgttagccaggatggtagaatctaccgttttaac
3	gcccgccaccacgcctggctaattttttgtatttt-----tttttagtagaggcagggtttcactgtgttagccaggatggtagaatctacccttttaac
4	gcccgccaccacgcctggctaattttttgtatttt-----tttttagtagaggcagggtttcactgtgttagccaggatggtagaatctacccttttaac
5	gcccgccaccacgcctggctaattttttgtatttt-----tttttagtagaggcagggtttcactgtgttagccaggatggtagaatctacccttttaac
6	gcccaccaccatgcctggctaattttttgtatttt-----tttttagtagaggcagggtttcactgtgttagccaggatggtagaatctacccttttaac


y=0 OE:	ass	chr1	180294965	180294965	-	0
1	aaaagagaagaaa-caggctggttgctgtggctcacacctgtaatcccagcactttgggagaccagtgcggaaggatcacttgagactaggagttcaaga
2	aaaagagaagaaac-aggctgggtgctgtggctcacacctgtaatcccagcactttgggagaccagtgtggaaggatcacttgaggctaagagttcgaga
3	aaaagagaagaaac-aggctgggtgctgtggctcacacctgtaatcccagcactttgggagaccagtgcagaaggatcacttgagactaagagttcgaga
5	aaaagagaagaaac-aggctggatgctgtggctcacacctgtaatcccagcactttgggagaccagtgcagaaggatcacttgagactaagagttcgaga
6	aaaagagaagaaac-aggctgggtgctgtggctcacacctgtaatcccagcactttgggagaccagtgcggaaggatcacttgagactaagagttcgaga


y=0 OE:	ass	chr1	180884714	180884714	+	0
2	tatttgttacacatagttttctcattatttatgaaacttaaccatac-agaatgatataactcctgtgcaatgaaggtgataacagtaaaagaaggcagg
3	tatttgttacacatagttttctcattatttatgaaacttaaccatac-agaatgatataactcctgtgcaatgaaggtgataacagtaaaagaaggcagg
4	tatttgttacacatagttttctcattatttatgaaactcaaccatac-agaatgatataactcctgtgcaatgaaggtgataacagtaaaagaaggcagg
5	tatttgttacacatagttttctcattatttatgaaacttaaccatac-agaatgatataactcctgtgcaatgaaggtgataacagtaaaagaaggcagg
6	tatttgttacacatagttttctcattatttatgaaacttaaccatac-agaatgatataactcctgtgcaatgaaggtgataacagtaaaagaaggcagg
10	tatttgttacataaagttttctcattatttatgaaacttaaccataaaagaatgatataacacctgtgcaatgaaggtgataacagtgaaagaagacagg
11	tatttgttacataaagttttctcattatttatgaaacttaaccataaaagaatgatataactcctgtgcaatgaaggtgataacagtgaaagaagatagg
14	tatttgttacatatagttttctcattatttatgaaatttaaccataaaagaatgatattactcctgtgtaatgaaggtgacatccatgaacaaaggcagg


y=0 OE:	ass	chr1	181789243	181789243	-	0
2	ctgctacagagtttttatgatattta---aatgacctgcctaaatgtcagtca-tcttcctcacttgtggcatc-tcctgagaacc-actgggaacaaga
3	ctgctacagagtttttacagtattta---aatgacctgcctaaatgtcagtca-tcttccccacttgtggcatc-tcctgagaacc-actgggaacaaga
4	ctgctacagagtttttacagtattta---aatgacctgcctaaatgtcagtca-tcttccccacttgtggcatc-tcctgagaacc-actgggaacaaga
5	ctgctacagagtttttacagtattta---aatgacctgcctaaatgtcagtca-tcttccccacttgtggcatc-tcctgagaacc-actgggaacaaga
6	ctgctacagagtttttatgatattta---aatgacctgcctaaatgtcagtca-tcttccccacttgtggcatc-tcctgagaacc-actgggaacaaga
14	ctcccacagagcca-tttgatattta---aatgacctgtctaaatatcagtc---ctttcttgg-tgtgccttc-tcttgaaaatcaa--gggaaaatga
15	ctgctcctgagtca-c-tgatattta---aatgatctgcctaaatgtcagtc---ctctcgtgg-tgtgtcctc-ccctgaaa-atca--aagagcagga
31	ctgtgacagagcca-cctaatatttatttaatcacatgcttaaatgccagtcactccaccccag-tgtgcttt-ctcttgagaata-actgggaacaaga


y=0 OE:	dss	chr1	181712686	181712686	-	0
1	aaatctgcttgccctcccatggcaagcctgagttaccattctgggaagcggtaggggacattcatgtctgcttcatccctacacaacagccttggaggag
3	aaatctgcttgacctcccatggtaagcctgagttaccattctgggaagcggtaggggatattcatgtccacttcatccctacacaacagccttggaggag
4	aaatctgcttgacctcccatggtaagcctgaattaccattctgggaagcggtaggggatattcgtgtccacttcatccctacacaacagccttggaggag
5	aaatctgcttgacctcccatggtaagcctgagttaccattctgggaagcggtaggggatatttgtgtccacttcatccctacacaacagccttggaggag
6	aaatctgcttgacctcccatggtaagcctgagttaccattctgggaaatggtaggggatattcgtgtccacttcatccctacaaaacagccttggaggag
9	aaatctgctcaccctcccatggtacggttgagttatcgttctggaaaaaggta-----gatgcatattcagctc-cccctacacaacagccttagaggga
11	agatcaattcaccctcctatggtaatgctgagttactgtttcaggaagaggtagg-gagagtcgtacttacgac-accctacacaactgccttgaaggag


y=0 OE:	dss	chr1	181916905	181916905	+	0
1	aaactt---gtgtctaacggaccattgctgtccagaacagacagatgagggtaat--agagaatgtttgcagtaccaagaaaagaccgaagatggagcca
2	aagctt---gtgtctaacggacgattgctgtccagaacagagagatgagggtaat--agagaatgtttgaagtgccaagaaaagaccaaagatggagcca
3	aagctt---gtgtctaatggaccattgctgtccagaacagagagatgagggtaat--agagaatgtttgaagtaccaagaagagacaaaagatggagcca
4	aagctt---gtgtctaacggaccattgctgtccagaacagagagatgagggtaat--agagaatgtttgaagtaccaagaagagacaaaagatggagcca
5	aagctt---gtgtctaacggaccattgctgtccagaacagagagatgagggtaat--agagaatgtttgaagtaccaagaagagacaaaa-atggagcca
6	aagctt---gtgtctaacagaccattgctgtccagaacagagagatgagggtaat--agagaatgtttgaagtaccaagaaaagacaaaagatggagcca
7	gggcac---atgcctaacatacgactgctgtccaaatcacag--atgagggtaat--agaggatgcttgaagtaccaaggaaagacaaagggtggagccg
9	agacac---atatctgacatgccattgcagtcctaaacaaagatatgaaggtagt--aaaggacatctgaagtagtaagaaaagctcagagatggagacc
27	agacacagg-ggtctaacagaccattgcagtccaaaaca--gggatgagg--gtaataggggatgttctaaataccaagaaaagaccaaggatggaggca


y=0 OE:	dss	chr1	180245662	180245662	-	0
1	agcaaacggattgatacagggaccatttttaggacaggccccagtatacagtaggtgctcaagacaggcttcctactattaggagataactgtcaagccc
2	agcaaacggactgatacacggacaatttttaggacaggccctggtatacagtaggtgctcaagacaggcttgctattattaggagataactgtcatgccc
3	agcaaacggattgacacatggacaatttttaggacaggccctggtatacagtaggtgctcaagacaggcttgctattattaggagataactgtcatgccc
4	agcaaacggattgacacatggacaatttttaggacaggccctggtatacagtaggtactcaagacaggcttgctattattaggagataactgtcatgccc
5	agcaaacggattgacacatggacaatttttaggacaggccctggtatacagtaggtgctcaagacaggcttgctattattaggagataactgtcatgccc
6	agcaaacggattgacacatggacaatttttaggacaggccctggtatacagtaggtgctcaagacaggcttgctattattaggagataactgtcatgccc


y=0 OE:	ass	chr1	180798257	180798257	+	0
0	aagcaaagaaaaagaaa--attaagattga-taactgtattc-ttaaaagggccaattagaactttttaaaaaatttaaaatgaacatgtaatcattgac
2	aaacaaagaagaagaaatcattaaaattgactaggcatattt-tttaaaggaccaattagatctt---------ttacaaatgaaaatataatcacagaa
3	aaacaaaga---agaaatcattaaaattaactaggcat-ttt-tttaaaggaccaattagatctt---------ttacaaatgaaaatataatcacggaa
4	aaacaaaga---agaaatcattaaaattgactaggcat-ttt-tttaaaggaccaattagatctt---------ttacaaatgaaaatataatcacggaa
5	aaacaaaga---agaaatcattaaaattgactaggcat-tttttttaaaggaccaattagatctt---------ttacaaatgaaaatataatcacggaa
6	aaacaaagaagaagaaatcattaaaattgactaggcatattt-tttaaaggaccaattagatctt---------ctacaaatgaaaatataatcacagaa


y=0 OE:	ass	chr1	181998319	181998319	-	0
1	aaagtcatgatcttaatagggaaagcatgtgattttgactcttggaatagatctttgcatatatgcgcttcgaacttcaatttcccctgaaccctc--tg
4	aaagtcatgatcttaatagggaaagcatgtgattttgactcttggaatagatctttgcatatatgcacttcgaactttaatttcccctgaaccctc--ca
5	aaagtcatgatcttaatagggaaagcatgtgattttgactcttggaatagatctttgcatatatgcacttcgaactttaatttcccctgaaccctccccg
6	aaagtcatgatcttaatagggaaagcatgtggttttgactcttggaatagatctttgcatatatgcacttcgaactttaatttcccctgaaccctc--ca


y=0 OE:	dss	chr1	181868634	181868634	-	0
2	ttgaaattcaatactcaatattagaagtgagcataatgggaagtgtttgggtaataggggcagattcctcatgaatgtcttggtgccatcctcacagtaa
3	ttgaaattcaatactcaatattagaagtgagcctaatgggaagtgtttgggtaataggggcagattcctcatgaatgtcttggtgccatcctcacagtaa
4	ttgaaattcaatactcaatattagaagtgagcctaatgggaagtgtttgggtaataggggcagattcctcatgaacgtcttggtgccctcctcacagtaa
5	ttgaaattcaatactcaatattagaagtgagcctaatgggaagtgtttgggtaataggggcagattcctcatgaacgtcttggtgccatcctcacagtaa
6	ttgaaattcaatactcaatattagaagtgagcctaatgggaagtgtttgggtaataggggcagattcctcatgaatgtcttggtgccatcctcacagtaa


y=0 OE:	ass	chr1	180780900	180780900	+	0
1	gtttgcaaatgttttctcccattgtgtttgtctt-ttacttttttgatagtgcccttttaagcagaaaagtttttaattttgataaagttcaatctatca
2	gtttgcaaatattttctcccattgtgtttgtctttttacttttttgatagtgcccttttaagcagaaaagttttcaattttgataaaattcaatctatca
3	gtttgcaaatgttttctcccattgtgtttgtctttttacttttttgatagtgcccttttaagcagaaaagtttttaattttgataaaattcaatctatca
4	gtttgcaaatgttttctcccattgtgtttgtctttttacttttttgatagtgcccttttaagcagaaaagtttttaattttgataaagttcaatctatca
5	gtttgcaaatgttttctcccattgtgtttgtctttttacttttttgatagtgcccttttaagcagaaaagtttttaattttgataaagttcaatctatca
6	gtttgcaaatgttttctcccattgtgccc--ttttttacttttttgatagtgcccttttaagcagaaaagtttttaattttgataaagttcaatctgtca


y=0 OE:	ass	chr1	180233300	180233300	+	0
2	cactctgtcctggcctcccgcctccgcaggctcccgtgcggac-tagcagttcgcgccgtagccctcctggttttttaccgcgccttggtcgcgcggccc
3	cactctgtcccggcctcccgcccccgcaggctcccgtgcggacttagcagtttgcgccgtagccctcctggttttttaccgcgccttggtcgcgcggccc
4	cactctgtcccggcctcccgcccccgcaggctcccgtgcggacttagcagttcgcgccgtagccctcctggtttttcaccgcgccttggtcgcgcggccc
5	cactctgtcccggcctcccgcccccgcaggctcccgtgcggacttagcagttcgcgccgtagccctcctggttttttaccgcgccttggtcgcgcggccc


y=0 OE:	ass	chr1	180577310	180577310	+	0
0	gtt------------tgtcctttgaattccatcccctcttaagcctgtaggtctgtaataaacat---ctatcttct-tttctgtcgtagggacattcct
2	attttcctttgaatttctcctttgaatttaatgctctcccgaatctgtaggtctgtgacaaacacttactgtcatttttttctctcttcagggcgttcct
3	attttcctttgaatttctcctttgaatttcatgctttcccaaatctgtaggtctgtgacaaacacctactgtcatttttttctctcttcagggcattcct
4	attttcctttgaatttctcctttgaatttcatgctttcccaaatctgtaggtctgtgacaaacacctactgtcatttttttctctcttcagggcattcct
5	attttcctttgaatttctcctttgaatttcatgctttcccaaatctgtaggtctgtgacaaacacctactgtcatttttttctctcttcagggcattcct
6	attttcctttgaatttctcctttgaatttcatgctctcccaaatctgtaggtctgtgacaaacacctactgtcatttttttctctcttcagggcattcct


y=0 OE:	ass	chr1	181247230	181247230	+	0
3	acgtttgttcagctccctgacgattggtgagttgtctgtgtattgtccagggtaactatgggtcatgtggagtctaaacattatgcttatctctgctata
4	acgcttattcagctccctgacgattggtgagttgtctgtgtattgtctagggtaactatgggtcatgtggagtctaaacattatgcttatctctgctata
5	acgcttgttcagctccctgacgattggtgagttgtctgtgtattgtccagggtaactatgggtcatgtggagtctaaacattatgcttatctctgctata


y=0 OE:	dss	chr1	180587690	180587690	+	0
3	aacttgtcctgcaaatgtaccccaggagacagaagaagccctctaagaaggtataactctctttccaatatgtcaatggccaagtttttctgccaaggga
4	aacttgtcctgcaaatgtaccccaggagacagaagaagccctctaagaaggtataactctctttccaatatgtcaatggccaagtttttctgccaaggga
5	aacttgtcctgcaaatgtaccccaggagacagaagaagccctctaagaacgtataactctcttttcaatatgtcaatggccaagtttttctgccaaggga
6	aacttgtcctgcaaatgtatcccaggagacagaagaattcctctaagaaggtataactctctttccaatatgtcaatggccaagttcttctgccaaggga


y=0 OE:	ass	chr1	181279551	181279551	-	0
3	ttcggtgtgccagtattttattgaggatttttgcatcaatgttcatcaaggatattggtctaaaattc--tttttcggttgtgtctctgccaggctttgg
4	ttcggtttgccagtattttattgaggatttttgcatcaatgttcatcaaggatattgttctaaaattctcttttttggttatgtctctgccaggctttgg
5	ttcggtttgccagtattttattgaggatttttgcatcaatgttcatcaaggacattggtctaaaattctctttttttgttgtgtctctgccaggctttgg


y=0 OE:	ass	chr1	181377759	181377759	-	0
3	tgggcaagtcatttaacctcattatgcattcattttttactgtagcacaggaattattacagtatcaatatcagaagttattgtgaagattaaatgattt
4	tgggcaagtcatttaacctcattatgcattcattttttactgtagcacaggaattattatagtatcaatatcagaagttattgtgaagattaaatgattt
5	tgggcaagtcatttaacctcattatgcattcattttttactgtagcacaggaattattatagtgtcaatatcagaagttattgtgaagattaaatgattt
6	tggacaagtcatttaacctcattatgcattcattttttactgtagcacaggaattattacagtatcaatatcagaggttactatgaagattaaatgattt


y=0 OE:	ass	chr1	181883133	181883133	-	0
2	---tttttgatgttgatgctattcctgtttgttagttttccttctaacagtcaggtccctcagctgcaggtctgttggagtttgctggaggtccactcca
3	ttttttttgatgttgatgctattcctgtttgttagttttccttctaacagtcaggcccctcagctgcaggtctgttggagtttgctggaggtccactcca
4	---tttttgatgttgatgctattcctgtttgttagttttccttgtaacagtcaggcccctcagctgcaggtctgttggagtttgctggaggtccactcca
5	---tttttgatgttgatgctattcctgtttgttagttttccttgtaacagtcaggaccctcagctgcaggtctgttggagtttgctggaggtccactcca


y=0 OE:	dss	chr1	181662533	181662533	-	0
1	atcttatatgacaaacgccaacatccttattcacatttgggtaattgaaggtatagaaaagtgaaataatttacctaacatcattgtcatagctggcaag
2	atcttatatgacagacaccaatatccttattcacaattgggtaactgaaggtatagaaaagtgaaataatttacctaacatcattgtcatagctggcaag
3	atcttatatgacaaacaccaatatccttattcacaattgggtaactgaaggtatagaaaagcgaaataatttacctaacatcattgtcatagctggcaag
4	atcttatatgacaaacaccaatatccttattcacaattgggtaactgaaggtacagaaaagtgaaataatttacctaacatcattgtcatagctggcaag
5	atcttatatgacaaacaccaatatccttattcacaattgggtaactgaaggtatagaaaagtgaaataatttacctaacatcattgtcatagctggcaag
6	atcttatatgacaaacaccaccatccttattcacaattgggtaactaaaggtataggaaagtgaaataatttacctaacatcattatcatagctggcaag


y=0 OE:	dss	chr1	181276852	181276852	-	0
3	tgttttttccccatctttttggttttatctacctttggtctttgatgatggtgatgtacagatgggtttttggtgtggatgtcctttctgtttgttagtt
4	tgttttttccccatctttttggttttatctacttttggcctttgatgatggtgatgtacagatgggtttttggtgtggatgtcctttctgtttgttagtt
5	tgttttttccccctctttgtggttttatctacctttggtctttgaagatggtgatgtacagatgggtttttggtgtggatgtcctttctgtttgttagtt


y=0 OE:	ass	chr1	181247374	181247374	-	0
3	ttttccaccaacatgatcccatagttccacatttaacattcccttttcaggaaaccaaggacagtgttcttccactgccctgaatagggtgacaatattt
4	ttttccaccaacatgatcccatagttccacatttaacattcccttttcaggaaaccaaggacagtgttcttccaccgccctgaatagggtgacaatattt
5	ttttccaccaacatgatcccatagttccacatttaacattcccttttcaggaaaccaaggacagtgttcttccaccaccctggatagggtgacaatattt


y=0 OE:	ass	chr1	180032661	180032661	+	0
1	gtttaatctccttttttttttttttttttttttaacttgtttggctatagtcactctttgtccccaagctctttctctttctttttgggaaagcttattg
2	gtttaacctctttttttttttttttt---------cttatttggctatagtcactctttgtccccaagctcttttgctttctttttgggaaagcttatta
3	gtttaacctctttttt----tttttt---------cttatttgcctgtagtcactctttgtccccaagctcttttgctttctttttgggaaagcttatta
4	gtttaacctcttttttt---tttttt---------cttatttgcctgtagtcactctttgtccccaagctcttttgctttcttttggggaaagcttatta
5	gtttaacctctttttt----tttttt---------cctatttgcctgtagtcactctttgtccccaagctcttttgctttcttttggggaaagcttatta
6	gtttaacctctttttt----ttgttt---------cttatttggctgtagtcactctttgtccccaagctcttttgctttctttttgggaaagcttatta


y=0 OE:	ass	chr1	180881943	180881943	-	0
1	agtgctcccctgccccagcttcttcaaactctgcttccttgggatcacagtaccaaccatgcttcgttttgatgcccttcctactacctccctgactact
2	agtgctcccctgccccagcttcttcaaactctgtttccttgggatcacagtaccaaccatgctttgttttgatgctcttcctattatctc-ctgactatt
3	agtgctcccctgccccagcttcttcaaactctgcttccttgggatcacagtaccaaccatgctttgttttgatgctcttcctattacctccctgactatt
4	agtgctcccctgccccagcttcttcaaactctgcttccttgggatcacagcaccaaccatgctttgttttgatgctcttcctattacctccctgactatt
5	agtgctcccctgccccagcttcttcaaactctgcttccttgggatcacagcaccaaccatgctttgttttgatgctcttcctattacctccctgactatt
6	agtgctcccctgccccagcttcttcaaactctgcttccttgggatcacagtaccaaccatgctttgttttgatgctcttcctattacctccctgactatt


y=0 OE:	dss	chr1	181957675	181957675	-	0
1	ttcccaaattattttatagattcaataccatcactatcaataccatcaaggtgcgattgactttcttcacagaattaggaaaaactactttaaattacat
2	--------gtgatttatagattcaatagtatc---------cccatcaaggtacaattgactttcttcacaaaattagaaaaaactactttaaatttcat
3	--------gtaattgatagattcagtagtatc---------cccatcaaggtacaattgactttcttcacaaaattagaaaaaactactttaaattttat
4	--------gtaatttatagattcggtagtatc---------cccatcaaggtacaattgactttcttcacaaaattagaaaaaactactttaaattttat
5	--------gtaatttatagattcagtagtatc---------cccatcaaggtacaactgactttcttcacaaaattagaaaaaactactttaaattttat
6	--------gtaatttatagattcaatagtatc---------cccatcaaggtacaattgactttcttcacaaaattagaaaaaactactttaaatttcat


y=0 OE:	ass	chr1	181482702	181482702	-	0
1	ccacagaccgaacttcctcactaacggctgggtcttcctcttccacccaggcagcgcc-ctcggcggagcactaga-gaagatgcggaaggagagggggg
2	ccacagaccgaacttcctcactaacggctcggtcttcctcttccacccaggcagcgcc-ctccgcggagcgctgga-gaagatgcggaaggagaaggggg
3	ccacagaccgaacttcctcactaacggctcggtctccctcttccccgcaggcagcgcc-ctcggcggagcactgga-gaagatgcggaaggagaaggggg
4	ccacagacctaacttcctcactaacggctcagtctccctcttccccgcaggcagcgcc-ctcggcggagcactgga-gaagatgcggaaggagaaggggg
5	ccacagaccgaacttcctcactaacggctcagtctccctcttccccgcaggcagcgcc-ctcggcggagcactgga-gaagatgcggaaggagaatgggg
6	ccacagaccgaacttcctcactaacggctcggtcttcctcttccacccaggcagctcc-ctcggcggagcactgga-gaagatgcggaaagagaaggggg
17	ctaaggaccgaacttcctcagtaacgaccaggtcttccttttgcacccagcccgcccagctgcactgag----cagagaagacgc-aggagaggcg--gg


y=0 OE:	dss	chr1	181113944	181113944	-	0
1	tgcaagcaatatacacgtgtgactatttcaatgctcatccccagatgaatgtaacaaatagggaattgggtgcctagagatgattggtcctggcaattta
2	tgcaagcaatacatacgtgtgactgtttcaatgctcatccccagatgaatgtaacaaattgggaattgggcgcttagagatgattggtcctggcaattta
3	tgcaagcaatatatacgtgtgactatttcaatgctcatccccagatgaatgtaacaaattgggaattgggcgcctagagatgattggtcctggcaattta
4	tgcaagcaatatatacgtgtgactatttcaatgctcatccccagatgaatgtaacaaattgggaattgagcgcctagagatgattggtcctggcaattta
5	tgcaagcaatatatacgtgtgactatttcaatgctcatccccagatgaatgtaacaaattgggaattgggcgcctagagatgattggtcctggcaattta
6	tgcaagcaatatatacgcatgactatttcaatgctcatccccagatgaatgtaacaaacagggaactgggcgcctagagatgattggtcctggcaattta


y=0 OE:	dss	chr1	181654622	181654622	+	0
3	cataactgggagattatataggtaaaatattggatgtataccatggcacagtatgtagcagtatgtactgtggcatcctatgtagcacagagcaacaaat
4	cataactgggagattatataggtaaaatattggatgtataccatggcacagtatgtagcagtatgtactgtggcatcctatgtagcacagagcaacaaat
5	cataactgggagattatataggtaaaatattggatgtataccatggcacagtatgtagcagtatgtactgtggcatcctatgtagcacagagcaacaaat


y=0 OE:	ass	chr1	181703966	181703966	+	0
0	agtgctttgggtgatgccatttatttgcctta--------accactttaggca-aagatttctgctcataggaggagccttcccaaagctc-ttgattct
1	agcactccatgtaatgccatttatttgcctta--------cctactttaggga-aggatttctgcttatcggaggagccttccgaaaactt-cagattcg
3	agcacttcatgtaatgccatttatttgcctta--------accactttaggga-aggatttctgctcataggaggaaccttccgaaagctc-cagattct
4	agcacttcatgtaatgccatttatttgcctta--------accactttaggga-aggatttctgctcataggaggagccttccgaaagctc-cagattct
5	agcacttcatgtaatgccatttatttgcctta--------accactttaggga-aggatttctgctcataggaggagccttctgaaagctc-cagattct
6	agcacttcatgtaatgccatttatttgcctta--------accactttaggga-aggatttctgctcataggaggagctttctgaaagctc-cagattct
11	agcgct--------------t-atgtcccttaagcatttttccacttcaggaa-aggacttctgctcacaggaggagccttcccaaagctc-cagatgct
22	ggcactctggttaagactgtttatttgcctta--------actgctttagggaaa-gactttttctcatgggaggagccctcccaaagc-cctgaccttt


y=0 OE:	ass	chr1	180586046	180586046	-	0
2	aaactcctgcc-atcttcctgtgtagttttggcctggctgtccttgccaggcacccttaagaagcttcagcctcagattttaa-aagctgtgtaactttt
3	aaactcctgcc-atcttcctatgcagttttggcctggctgtccttgccaggcaccctcaagaagctccagcctcagattttaa-aagctgcgtaactttt
4	aaactcctgcc-atcttcctatgcagttttggcctggctctccttgccaggcaccctcaagaagctccagcctcagattttaa-aagctgtgtaaatttt
5	aaactcctgcc-atcttcctatgcagttttggcctggctgtccttgccaggcaccctcaagaagctccagcctcagattttaa-aagctgtgtaactttt
6	aaactactgcc-gtcctcctgtgcagttttggcctggctgtccttgccaggcaccctcaagaagctccagcctcagattttaa-aagctgtgtaactttt
9	gaaatccaacaaatctccccacacagttttgctccagctgtccttattaggcactctcaagaagttctagtctgagatgttaaaaagacatatgatgttt
27	gaagtccaacc-atcttcctgtg--------------ctttcatggctaggtactctcaagaagctccaacctgagattttag-aaggcacaagcttttt


y=0 OE:	ass	chr1	180065867	180065867	+	0
3	aagaaaggcatttctttcaataaaatttctataaaattttaattttatagaaattaaagaaattttcaataaaatttctttctactaatttggggaagca
4	aagaaagacatttctttcaataaaatttctataaaattttaattttatagaaattaaagaaattttcaataaaatttctttctactaatttggggaagca
5	aagaaaggcatttctttcaataaaatttctataaaattttaattttatagaaattaaagaaattttcaataaaatttctttctactaatttggggaagca


y=0 OE:	ass	chr1	180609002	180609002	+	0
3	agttctggaaattattaagctttttt---ttgtttgtttttcagagacagggtcttgctttattttccaggctggagtgcagtggcacaataatagctca
4	agttctggaaattattaagcttt-tt---ttgtttgtttttcagagacagggtcttgctttattttccaggctggagtgcagtggcacaataatagctca
5	agttctggaaattattaagctttttt---ttgtttgtttttaagagacagggtcttgctttattttccaggctggagtgcagtggcacaataatagctca
6	aattctggaaattattaagctttttttgtttgtttgtttttcagagacagggtcttgctttattttccaggctggagtgcagtggcacaataatagctca


y=0 OE:	ass	chr1	181573259	181573259	+	0
1	agacagcaagcaccctgcatttgtcactgtggtgtttcccattctcatagcactttgtaaacaactctgttataatgcttcatggtgtgttataattatt
2	tgacagcaagcaccttgtatttgtcactgtggtgtttcccattctcatagcactttgtaaccaactctgttataatgcttcatggtgtgttacaattatt
3	tgacagcaagcaccttgtatttgtcactgcggtgtttcccattctcatagcactttgtaactaactctgttataatgcttcatggtgtgttataattatt
4	tgacagcaagcaccttgtatttgtcactgcggtgtttcccattctcatagcactttgtaactaactctgttataatgcttcatggtgtgttataattatt
5	tgacagcaagcaccttgtatttgtcactgcggtgtttcccattctcatagcactttgtaactaactctgttataatgcttcatggtgtgttataattatt
7	cgatagtaaccactctgt--ttatcacggcggtttc---tgttctcatagcactttgtgaac------------actcatcatgcc-----------act


y=0 OE:	dss	chr1	180005681	180005681	-	0
1	tcagagac--ataactaaggaccagatcatgcagggctatttaggccattgtaagaatttcaggtttcactcaagagtgagatggaaggttttgagagat
2	tcagagacatataactaagggccagatcatgcagggccatctaggccattgtaagaatttcaggttttactcaagagtgagatggaaggttttgagagat
4	tcagagacatataactaagggccagatcatgcagggccatctaggccactgtaagaatttcaggttttactcaagaatgagatggaaggttttgagagat
5	tcagagacatataactaagggctagatcatgcagggccatctaggccactgtaagaatttcaggttttactcaagaatgagatggaaggttttgagagat
6	tcagagacatataactaagggccagatcatgcagggccatctaggccattgtaagaatttcaggttttactcaagagtgagatggaaggttttgagagat


y=0 OE:	ass	chr1	181682264	181682264	-	0
1	caagtcctagatgtacttaaaagtattgtgtatcccatcctctttggaaggaagctaagaaaaacctgacaaggtcaac-tgaactatggtcacatgggg
2	caagtcctaaatgtacttaaaagtactgtgtat-----cctctttggaaggaagctaagaaaaacctgacaaggtcaac-ggagctgtggtcacacgggg
3	caagtcctaaatgtacttaaaagtattgtgtatctcatcctctttggaaggaagctaacaaaaacctgacaaagtcaac-t-aactatggtcacacgggg
4	caagtcctaaatgtacttaaaagtattgtgtatcccatcctctttggaaggaagctaagaaaaacctgacaaagtcaac-tgaactatggtcacacgggg
5	caagtcctaaatgtacttaaaagtattgtgtatcccatcctctttggaaggaagctaagaaaaatctgacaaagtcaac-tgaactatggtcacacgggg
6	caactcctaaatgtacttaaaagtattgtgtatcccatcctctttggaaggaagctaagaaaaacctgataaggtcaac-tgaactatggtcacacgggg
15	agaatactcaacatctacaaaaccattgtgtatctcatcctcctctgaagaaggctgtggaaaacctgatgagagggcc-tgaactgcagttaaatggag
17	caagtcc----t-----taaaactattacatgttccatcctctttcaaaggaggctaagaaaaacctgaggaggttgac-tcaacgatggtcacatggag
29	--tgttct-gaagttcttaaaactactgtgtgtcccagcctcctgtgaagaaagctacaaagaatctgagaagactgatttaatt-atggtctcaagaca


y=0 OE:	dss	chr1	181678734	181678734	-	0
1	tttccagatggagaaactaaggctgagaaaggttagaacatgtgcccaaggtgacacagctagttaaatgaagaattaggatttgagccctgtaatccaa
2	tttccaggtggagaaactaagtctgagaaaggttagaaaatgtgcccaaggtgacacagctaattaaatgaagaactaggatttgagccctgtaatccaa
3	tttccaggtggagaaactaagtctgagaaaggttagaaaatgtgcccaaggtgacacagctaattaaatgaagaatgaggatttgagccctgtaatccaa
4	tttccaggtggagaaactaagtctgagaaaggttagaaaatgtgcccaaggtgacacagctaattaaatgaagaatgaggatttgagccccgtaatccaa
5	tttccaggtggagaaactaagtctgagaaaggttagaaaatgtgcccaaggtgacacagctaattaaatgaagaatgaggatttgagccccgtaatccaa
6	tttccaggtggagaaactaagtctgagaaatgttagaaaatgtgcccaaggtgacacagctaattaaatgaagaattaggatttgagccctgtaatccaa


y=0 OE:	ass	chr1	180879684	180879684	+	0
1	ttaatgacggcatactctattccct-tgtcctgctttattttcttcacagtatttatcattagccgattgattgtttacttgctcattgtctgtctccac
2	ttaatgacggcatactgtattccct-tgtcctgctttattttcttcacagtacttatcattagccgattgattgtttacttgctcattgtctgtctccac
3	ttaatgatggcatactctattccct-tgtcctgctttattttcttcacagtacttatcattagccgattgattgtttacttgctcattgtctgtctccac
4	ttaatgatggcatactctattccct-tgtcctgctttattttcttcacagtacttatcattagccgattgattgtttacttgctcattgtctgtctccac
5	ttaatgatggcatactctattccct-tgtcctgctttattttcttcacagtagttatcattagccgattgattgtttacttgctcattgtctgtctccac
6	ttaatgatggcatactctattccctttgtcctgctttattttcttcacagtacttatcattagccgattgattgtttacttgctcattgtctgtctccac


y=0 OE:	ass	chr1	180850171	180850171	+	0
1	ttgagataatacaggttttactctacttctaaaaatattttatttaaaagaaaaattaaatgaagttttatataaaaaggcatcacagttttgtactgtt
2	ttgagataatacatgttttactctacttctaaaactattttacttaaaagaaaaattaaatgaaggtttatataaaaaggcatcacagttttggactgtt
3	ttgagataatacaggttttactctacttctaaaaatattttatttaaaagaaaaattaaatgaaggtttatataaaaaggcatcacagttttggactgtt
4	ttgagataatacaggttttactctacttctaaaaatattttatttaaaagaaaaattaaatgaaggtttatataaaaaagcatcacagttttggactgtt
5	ttgagataatacaggttttactctacttctaaaaatattttatttaaaagaaaaatgaaatgaaggtttatataaaaaggcatcacagttttggactgtt
6	ttgagataatacaggttttactctacttctaaaaatactttatttaaaagaaaaattaaatgaaggtttatataaaaaggcatcacagttttggactgtt


y=0 OE:	ass	chr1	180705416	180705416	+	0
2	acatgcagttaattttgcaaataccctaatgcacatgaattttatttgaggttgagatgcctatac---------------gtgttggaaatgtagtgtg
3	ccatgcagttaattttgcaaataccctaatgcacatgaattttatttgaggttgagatgcctatatgtactctgaaacaaagtgttggaaatgtagtgtg
4	ccatgcagttaattttgcaaataccctaatgcacatgaattttatttgaggttgagatgcctatatgtactctgaaacaaagtgttggaaatgtagtgtg
5	ccatgcagttaattttgcaaataccctaatgcacatgaattttatttgaggttgagatgcctatatttactctgaaacaaagtgttggaaatgtagtgtg
6	acatgcagttaattttgcaaataccctaatgcacatgaattttatttgaggttgagatgcctatacatactctgaaacaaagtgttggaaatgtagtgtg


y=0 OE:	ass	chr1	181950323	181950323	+	0
2	gcttcacatatcacctctatcct-catcct---cattttcc--tct-gagattaaaac----cgtatattaaaacttttcat---cataacctgtgtgac
3	gcttcaaatatcacctctatcct-catcct---cattttcc--tct-gagattaaaat----tgtatattaaaacttttcat---cataacctgtgtgac
4	gcttcaaatatcacctctatcct-catcct---cattttcc--tct-gagattaaaat----tgtatgttaaaacttttcat---cataacctgtgtgac
5	gcttcaaatatcacctctatcct-catcct---cattttcc--tct-gagattaaaat----tgtatattaaaacttttcat---cataacctgtgtgac
6	gcttcaaatatcacctctatcct-catcct---cattttcc--tct-gagattaagat----tgtatattaaaacttttcat---cataacctgtgtgac
22	tga---aatattgcttttgcactc-attctctc-------cttgcttgagattaacattacaaa---ggtagaccctttcacatagataacc----tatg


y=0 OE:	dss	chr1	180208153	180208153	-	0
1	accactctacactctgcctatgcggtactgcaaggtacagggtctgcgaggtacaggattaagtgaaaaagaccaggtgctgagtggggttggtagtgtg
2	gccacttcacactttgcctatgctgacatggaa------gggtctgcaaggtacaggattaagtgaaaaagatcaggtgctgagtggggttggcagtgtg
3	gccactccgcccgttgcctatgctgacatggaa------gggtctgcaaggtacaggattaagtgagaaagatcaggtgctgagtggggttgatagtgtg
4	gccactccgccctttgcctatgctgacatggaa------gggtctgcaaggtacaggag-acctgagaaagatcaggtgctgagtggggttgatagtgtg
5	gccactccgccctttgcctatgctgacatggaa------gggtctgcaaggtacaggag-acccgagaaagatcaggtgctgagtggggttgatagtgtg


y=0 OE:	dss	chr1	181785105	181785105	+	0
1	gtgatgcttactcatgtactgcttatcctcagtatcatcaccatcactaggtgggcatgcaagccccctgaggacagatcaggggacctatgcactctgc
3	gtgatgcttactcatgtactgcttatcctcagtatcatcaccatcactaggtgggcatgcaagccccctgaggacagatcaggggatctatgcactctgc
4	gtgatgcttactcatgtactgcttatcctcagtatcatcaccatcactaggtgggcatgcaagccccctgaggacagatcaggggatctatgcactctgc
5	gtgatgcttactcatgtactgcttatcctcagtatcgtcaccatcactaggtgggcatgcaagccccctgaggacagatcaggggatctatgcactctgc
6	gtgatgcttactcatgtactgcttatcctcagtatcatcaccatcactaggtgggtatgcaagccccctgaggacagatcaggggacctatgcactctgc


y=0 OE:	ass	chr1	181666161	181666161	-	0
3	tctataattaaatgtctggtttgtaaagactgttttctcatgaatagcaggctgcattacagcagggagaacatttaaaaagacaattgctatagtccag
4	tctataattaaatgtctggtttgtaaagactgttttctcatgaatagcaggctgcattacagcagggagaacatttaaaaagacaattgctatagtccag
5	tctataattaaatgtctggtttgtaaagactgttttctcatgaatagcaggctgcattacagcagggagaacatttaaaaagacaattgctatagtccag
6	tctataattaaatgtctagtttgtaaagactgttttctcatgaatagcaggctgcattatagctgggagaacatttaaagagacaattgctatagtccag


y=0 OE:	dss	chr1	181363830	181363830	+	0
1	agcagtcagaaacaaggcagccagaagctgtggtttggtgcatgaaagtggtgagagcgctctgggaagggcagcaacagacttcactacagataggaga
2	agccatcagaaacaaggcacgcagaagctgtggtttggtgcatggaagtggtgagagagctctgggaagggtggcaacagacttcactacagataggaga
3	agccatcagaaacaaggcatgcagaagctgtggtttggtgcatggaagtggtgagagagctctgggaagggcagcaacagacttcactacggataggaga
4	agccatcagaaacaaggcgtgcagaagctgtggtttggtgcatggaagtggtgagagagctctgggaagggcagcaacagacttcactacggacaggaga
5	agccatcagaaacaaggcatgcagaagctgtggtttggtgcatggaagtggtgagagagctctgggaagggcagcaacagacttcactacggataggaga
6	agccatcagaaacaaggcacgcagaagctgtggtttggtgcatggaagtggtgagagagctctgggaagggtggcaacagatttcactacagataggaga


y=0 OE:	ass	chr1	180485984	180485984	-	0
2	ctcaacattcatgtatttatatcagtttagacttatggatttttattcagtggggtata---atccattaaaattatt--t---tttttggctactggga
3	ctcaacattcatgtgtttatatcagtttaggctcatggatttttattcagtgggatataaaaatccattaaaatcattatt---ttttttgctactggga
4	ctcaacattcatgtatttatatcagtttagactcatggatttttattcagtgggatataaaaatccattaaaatcattatt---ttttttgctactggga
5	ctcaacattcatgtatttatatcagtttagactcatggatttttattcagtgggatataaaaatccattaaaatcattttttttttttttgctactggga
6	ctccacattcatgtatttatatcagtttagactcatggatttttattcagtgggatata---atccattaaaatcattatt---tttttggctactggga


y=0 OE:	ass	chr1	181912507	181912507	-	0
1	aaaataacccaaagttttaattttacattatctatt-ggctattaaccagctattctaatgacccattgtgaaattctttaattattcagttagt-atgg
2	aaattaacccagagttttaattttacattatctatt-ggctattaaccagctattctaatgacccattgtcaaattgtttaataattcagttagt-atgg
3	aaattaacccagagttttaattttacattgtctatt-ggctattaaccagctattctaatgacccattgtcaaattgtttaataattcagtcagt-atgg
4	aaattaacccagagttttaattttacattatctatt-ggctattaaccagctattctaatgacccattgtcaaattgtttaataattcagtcagt-atgg
5	aaattaacccagagttttaattttacattatctatt-ggctattaaccagctattctaatgacccattgtcaaattgtttaataattcagtcagt-atgg
6	aaattaatccagagttttaattttacattatctatt-ggccattaaccagctattctaatgacccattgtcaaattgtttaataattcagttagt-atgg
19	aaattaacacaaagttttcattttatatcatcca---ttatatcactcagctattctaatgacccattgtcaggttgtttaataatacagttagcaatag
28	aaattaatcca-agttttaattttacattaatcatttggatattaaccagttgttctaatggccc------aagttgtttaataattcaattagt-acag


y=0 OE:	ass	chr1	181588165	181588165	+	0
1	ccgctgggccttctctaaggccactcccagggtgtctggtcctgtttcagctcaattcagaatatgaacttggggaacatttggggattgaaacccac--
2	ccgctgggccctctgtggcaccgctcccagggtgtctggtcctgtttcagctcaattcagaatgtgaacttggggaacatttggggactgaaacccac--
3	ccgctgggccctctgtggcaccgctcccagggtgtctggtcctgtttcagctcaattcagaatgtgaacttggggaacatttggggactgaaacccac--
4	ccgctgggccctctgtggcaccactcccagggtgtctggtcctgtttcagctcaattcagaatgtgaacttggggaacatttggggactgaaacccac--
5	ccgctgggccctctgtggcaccactcccagggtgtctggtcctgtttcagctcaattcagaatgtgaacttggggaacatttggggactgaaacccac--
9	t-tctgagtctctagggaccttgctctg--tgcatctgatcctgctttagcccagttccaaatgttgacttgaagaatatttcaaaactaaaattcat--
10	t-cctgagttctcaagtacttcatt----------ctgacctttgctcagctcgggcccaaatgctggctcaaagcacgtttctg-------tccccctc


y=0 OE:	ass	chr1	181077014	181077014	+	0
1	ctgggcactgaggataca--cacagggcaagacctgccctctgcccccagggaagtcccagtccagagggacacagttgtatgatcaagacacagttgta
2	ctaggcactgaggacaca--cacagggcaagagctgccctctgcccccagggaagtcccagtccagaaggacacagttgtatgatcaagacacagttgta
3	ctaggcactgaggataca--cacagggcaagacctgccctctgcccccagggaagtcccagtccagagggacacagttgtatgatcaagacacagttgta
4	ctaggcactgaggataca--cacagggcaagacctgccctctgcccccagggaagtcccagtccagagggacacagttgtatgatcaagacacagttgta
5	ctaggcactgaggataca--cacagggcaagacctgccctctgcccccagggaagtcccagtccagagggacacagttgtatgatcaagacacagttgta
6	ctaggcactgaggataca--cacagggcaagacctgccctctgcccccagggaagtcccagtccagaggaacacagttgtatgatgaagacacagttgta
17	-agggaactgaggacataccaattgaacaagacctgccctttgccctcagggaagtcccagtccagagggctgctgtcatatgatca-gac---------


y=0 OE:	dss	chr1	180479456	180479456	+	0
3	tcacttgttctcat-tatatatatgagctaaaaaatttgatcacatggaggtaaagagtagaaagacacataacagagagtgggaggggcaagtaggggg
4	tcacttgttctcatttatatatatgagctaaaaaatttgatcacatggaggtagagagtggaaagacacataacagagagtgggaggggcaagtaggggg
5	tcacttgttctcatttatatatatgagctaaaaaatttgatcacatggaggtagagagtggaaagacacataacagagactgggaggggcaagtaggggg
6	tcacttgttctcatttatatatgtgagttaaaaaatttgatcacatggaggtagagagtggaaagacagataacagagagtgggaggggcgagtaggagg


y=0 OE:	ass	chr1	180051226	180051226	+	0
4	aacgaaatactattcagctattaaaaggaataatcttttgattcatgtagcaacatgaacgaattttacagtcctccgctctaccagacctctgctctac
5	aacgaaatactattcagctgttaaaaggaataatcttttgattcatgtagcaacatgaacgaattttacagtcctccgctctaccagacctccgctctac


y=0 OE:	dss	chr1	180859733	180859733	+	0
3	aaacattacttactctgaaatattctgtaagaatatttatttaaaaggcagtaagtcctcatgtatgtttcatagaaattgcatagaaatgatatggact
4	aaacattacttactctgaaatattctgtaagaatatttatttaaaaggcagtaagtcctcatgtatgtttcatagaaattgcatagaaatgatatggact
5	aaatattacttactctgaaatattctgtaagaatatttatttaaaaggcagtaagtcctcatgtatgtttcatagaaattgcatagaaatgatatggact


y=0 OE:	dss	chr1	181237412	181237412	+	0
1	gg-ggcatggcctgcgtagagtgaatgtctttgaataaatcgtctccaatgtgaattattgccactgacccttgggctgaggcatgggtggaccaggagc
2	gggggcatggcctgtgtagagggaatgtctttggataaattgtctccaatgtgaattattgccactgtccctagggctgaggcatgagtggaccaggagc
3	gggggcatggcctgtgtagagtgaatgtctttgaataaattgtctccaatgtgaattattgccattgtccctagggctgaggcatgggtggaccaggagc
4	gggggcatggcctgtgtagagtgaatgtctttgaataaattgtctccaatgtgaattattgccactgtccctagggctgaggcatgggtggaccaggagc
5	gggggcatggcctgtgtagagtgaatgtctttgaataaattgtctccaatgtgaattattgccactgtccctagggctgaggcatgggtggaccaggagc


y=0 OE:	ass	chr1	180805871	180805871	-	0
0	agac-------t--ttt---------cttatttcacttattcatttcaaggtagtaggctattagtaacaccaagaaactctgaacttatga--accct-
2	--actc-----ttctgt---------tttatttcttttattcatttcaaggtagtatgctattagtaacacaaagaaaccctgaac-tatga--accct-
3	--actc-----ttcttt---------tttattccttttattcatttcaaggtagtatgctattagtaacacaaagaaaccctgaac-tatga--accct-
4	--actc-----tt-ttt---------ttaattccttttattcatttcaaggtagtatgctattagtaacacaaagaaaccctgaac-tatga--accct-
5	--actc-----ttcttt---------tttattccttttattcatttcaaggtagtatgctattagtaacacaaagaaaccctgaac-tatga--accct-
6	--actc-----ttcttt---------tttattccttttattcatttcaaggtagtatgctattagtaacacaaagaaaccctgaac-tatga--atcct-
7	agactc-----ttct-------------ta-atcatttgtttgttttaaggtagtacgttatcagtaacacaaagaaaccctgagc-tattacaac----
9	aaacac-----atcagt---------cttatttcactttttcatgtcaaggtagtatgcaattaaaaataaaaacagactctctac-tacca--actgt-
24	agac--tcttctt---t---------ctcatttcatttattcatttcaaggtagtatgctattagtaatacaaagaaactccaga-ttatga--atcct-
26	agactc-----------aagattcttcttatcctatctatttatttcaaggtagtatgccatcagtaacaaaagaaacc-ctaaa-ttatga--accct-
27	agactc--ttctt---t---------cttatttcatttattcatttcaaggtagtatgctatcagtaacacaaagaatc-ctgga-ctatga--acccta
